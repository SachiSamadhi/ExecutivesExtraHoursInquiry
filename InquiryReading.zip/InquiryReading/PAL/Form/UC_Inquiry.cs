﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using System.IO;

namespace ExecutivesExtraHoursInquiry.PAL.Form
{
    public partial class Form1 : DevExpress.XtraEditors.XtraForm
    {
        BLL.BLL_CS_Inquiry BLL_CS_Inquiry = new BLL.BLL_CS_Inquiry();
        public Form1()
        {
            InitializeComponent();
        }

        private void txtServiceNo_EditValueChanged(object sender, EventArgs e)
        {
            ShowPhoto();
        }

        private void txtServiceNo_MouseDoubleClick(object sender, MouseEventArgs e)
        {

        }

        private void UC_Inquiry_Load(object sender, EventArgs e)
        {

            cmbMonth.Properties.Items.Add("January");
            cmbMonth.Properties.Items.Add("February");
            cmbMonth.Properties.Items.Add("March");
            cmbMonth.Properties.Items.Add("April");
            cmbMonth.Properties.Items.Add("May");
            cmbMonth.Properties.Items.Add("June");
            cmbMonth.Properties.Items.Add("July");
            cmbMonth.Properties.Items.Add("August");
            cmbMonth.Properties.Items.Add("September");
            cmbMonth.Properties.Items.Add("October");
            cmbMonth.Properties.Items.Add("November");
            cmbMonth.Properties.Items.Add("December");

            for (int year = 2002; year <= 2026; year++)
            {
                cmbYear.Properties.Items.Add(year.ToString());
            }

            cmbMonth.SelectedIndex = DateTime.Now.Month - 1;
            cmbYear.Text = DateTime.Now.Year.ToString();


        }

        private void gvmeter_DoubleClick(object sender, EventArgs e)
        {
            if (gvmeter.FocusedRowHandle >= 0)
            {
                txtServiceNo.Text = gvmeter.GetFocusedRowCellValue("v_service_no")?.ToString();
                txtName.Text = gvmeter.GetFocusedRowCellValue("v_name")?.ToString();
                txtBarcode.Text = gvmeter.GetFocusedRowCellValue("v_barcode_no")?.ToString();

                pnlService.Visible = false;
                //ShowPhoto();
            }
        }

        private void txtServiceNo_DoubleClick(object sender, EventArgs e)
        {
            pnlService.Visible = true;
            pnlService.BringToFront();
            gcmeter.DataSource = BLL_CS_Inquiry.ServiceNo();
        }

        private void ShowPhoto()
        {
            try
            {
                DataTable dt = BLL_CS_Inquiry.PhotoPath();

                if (dt.Rows.Count == 0)
                    return;

                string basePath = dt.Rows[0]["cpd_photo_path"].ToString();
                string serviceNo = txtServiceNo.Text.Trim();

                string fullPath = Path.Combine(basePath, serviceNo );

                if (File.Exists(fullPath))
                {
                    picturePath.Image = Image.FromFile(fullPath);
                }
                else
                {
                    string dummyPath = Path.Combine(basePath, "dummy_photo");
                    picturePath.Image = Image.FromFile(dummyPath);
                }

                picturePath.Visible = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Photo load error: " + ex.Message);
            }
        }

        private void cmbMonth_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbMonth.SelectedIndex >= 0)
            {
                string monthNumber = (cmbMonth.SelectedIndex + 1).ToString("00");
                
            }


        }

        private void labelControl11_Click(object sender, EventArgs e)
        {
            pnlService.Visible = false;
        }

        private void btnSummary_Click(object sender, EventArgs e)
        {
            LoadSummaryView();
        }
        private void LoadSummaryView()
        {
            if (string.IsNullOrWhiteSpace(txtBarcode.Text))
            {
                XtraMessageBox.Show(this.LookAndFeel,
                    "Please Select Barcode.",
                    "Executives Extra Hours Inquiry",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Exclamation);
                txtBarcode.Focus();
                return;
            }

            if (cmbYear.SelectedItem == null)
            {
                XtraMessageBox.Show(this.LookAndFeel,
                    "Please select Year.",
                    "Executives Extra Hours Inquiry",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Exclamation);
                cmbYear.Focus();
                return;
            }

            if (cmbMonth.SelectedItem == null)
            {
                XtraMessageBox.Show(this.LookAndFeel,
                    "Please select Month.",
                    "Executives Extra Hours Inquiry",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Exclamation);
                cmbMonth.Focus();
                return;
            }


            string barcodeNo = txtBarcode.Text.Trim();
            string year = cmbYear.Text;
            string month = cmbMonth.Text;

            gcInquiry.DataSource = BLL_CS_Inquiry.SummaryTable(barcodeNo, year, month);

           
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtServiceNo.Text = "";
            txtName.Text = "";
            txtBarcode.Text = "";

            
            cmbMonth.SelectedIndex = DateTime.Now.Month - 1; 
            cmbYear.Text = DateTime.Now.Year.ToString();

            
            if (picturePath != null)
            {
                picturePath.Image = null;
            }

            
            tblDataBindingSource.DataSource = null;
            gcInquiry.DataSource = null;
        }

        private void btnView_Click(object sender, EventArgs e)
        {
            try
            {
               
                if (string.IsNullOrWhiteSpace(txtBarcode.Text))
                {
                    XtraMessageBox.Show(this.LookAndFeel,
                        "Please enter a Barcode.",
                        "Validation",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Exclamation);
                    txtBarcode.Focus();
                    return;
                }

                if (cmbYear.SelectedItem == null)
                {
                    XtraMessageBox.Show(this.LookAndFeel,
                        "Please select a Year.",
                        "Validation",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Exclamation);
                    cmbYear.Focus();
                    return;
                }

                if (cmbMonth.SelectedItem == null)
                {
                    XtraMessageBox.Show(this.LookAndFeel,
                        "Please select a Month.",
                        "Validation",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Exclamation);
                    cmbMonth.Focus();
                    return;
                }

                
                string barcodeNo = txtBarcode.Text.Trim();
                string year = cmbYear.Text;
                string monthName = cmbMonth.Text;

                
                DataTable dt = BLL_CS_Inquiry.SummaryView(barcodeNo, year, monthName);

               
                gcView.DataSource = dt;

            }
            catch (Exception ex)
            {
                XtraMessageBox.Show(this.LookAndFeel,
                    "Error loading Summary View: " + ex.Message,
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
            pnlView.BringToFront();

        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void lblsup_Click(object sender, EventArgs e)
        {
            pnlView.Visible = false;
        }

        private void pnlView_Paint(object sender, PaintEventArgs e)
        {

        }

        private void gcView_Click(object sender, EventArgs e)
        {
            pnlView.Visible = false;
        }
    }
}