﻿namespace ExecutivesExtraHoursInquiry.PAL.Form
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            DevExpress.XtraReports.UserDesigner.XRDesignPanelListener xrDesignPanelListener1 = new DevExpress.XtraReports.UserDesigner.XRDesignPanelListener();
            DevExpress.XtraReports.UserDesigner.XRDesignPanelListener xrDesignPanelListener2 = new DevExpress.XtraReports.UserDesigner.XRDesignPanelListener();
            this.xrDesignBarManager1 = new DevExpress.XtraReports.UserDesigner.XRDesignBarManager(this.components);
            this.barDockControlTop = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlBottom = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlLeft = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlRight = new DevExpress.XtraBars.BarDockControl();
            this.xrDesignDockManager1 = new DevExpress.XtraReports.UserDesigner.XRDesignDockManager(this.components);
            this.recentlyUsedItemsComboBox1 = new DevExpress.XtraReports.UserDesigner.RecentlyUsedItemsComboBox();
            this.beiFontName = new DevExpress.XtraBars.BarEditItem();
            this.designRepositoryItemComboBox1 = new DevExpress.XtraReports.UserDesigner.DesignRepositoryItemComboBox();
            this.beiFontSize = new DevExpress.XtraBars.BarEditItem();
            this.bsiHint = new DevExpress.XtraBars.BarStaticItem();
            this.bbiFontBold = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiFontItalic = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiFontUnderline = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiForeColor = new DevExpress.XtraReports.UserDesigner.CommandColorBarItem();
            this.bbiBackColor = new DevExpress.XtraReports.UserDesigner.CommandColorBarItem();
            this.bbiJustifyLeft = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiJustifyCenter = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiJustifyRight = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiJustifyJustify = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiAlignToGrid = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiAlignLeft = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiAlignVerticalCenters = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiAlignRight = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiAlignTop = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiAlignHorizontalCenters = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiAlignBottom = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiSizeToControlWidth = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiSizeToGrid = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiSizeToControlHeight = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiSizeToControl = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiHorizSpaceMakeEqual = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiHorizSpaceIncrease = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiHorizSpaceDecrease = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiHorizSpaceConcatenate = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiVertSpaceMakeEqual = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiVertSpaceIncrease = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiVertSpaceDecrease = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiVertSpaceConcatenate = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiCenterHorizontally = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiCenterVertically = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiBringToFront = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiSendToBack = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiOpenFile = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiCut = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiCopy = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiPaste = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiUndo = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiRedo = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.msiTabButtons = new DevExpress.XtraBars.BarSubItem();
            this.barReportTabButtonsListItem1 = new DevExpress.XtraReports.UserDesigner.BarReportTabButtonsListItem();
            this.barSubItem1 = new DevExpress.XtraBars.BarSubItem();
            this.xrBarToolbarsListItem1 = new DevExpress.XtraReports.UserDesigner.XRBarToolbarsListItem();
            this.barSubItem2 = new DevExpress.XtraBars.BarSubItem();
            this.barDockPanelsListItem1 = new DevExpress.XtraReports.UserDesigner.BarDockPanelsListItem();
            this.msiFormat = new DevExpress.XtraBars.BarSubItem();
            this.msiFont = new DevExpress.XtraBars.BarSubItem();
            this.msiJustify = new DevExpress.XtraBars.BarSubItem();
            this.msiAlign = new DevExpress.XtraBars.BarSubItem();
            this.msiSameSize = new DevExpress.XtraBars.BarSubItem();
            this.msiHorizontalSpacing = new DevExpress.XtraBars.BarSubItem();
            this.msiVerticalSpacing = new DevExpress.XtraBars.BarSubItem();
            this.bsiCenter = new DevExpress.XtraBars.BarSubItem();
            this.msiOrder = new DevExpress.XtraBars.BarSubItem();
            this.commandBarItem2 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem3 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem4 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem5 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem6 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.msiWindow = new DevExpress.XtraBars.BarSubItem();
            this.msiWindowInterface = new DevExpress.XtraReports.UserDesigner.CommandBarCheckItem();
            this.commandBarItem8 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem9 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem10 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.msiWindows = new DevExpress.XtraBars.BarMdiChildrenListItem();
            this.commandBarItem11 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiZoomOut = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiZoom = new DevExpress.XtraReports.UserDesigner.XRZoomBarEditItem();
            this.designRepositoryItemComboBox2 = new DevExpress.XtraReports.UserDesigner.DesignRepositoryItemComboBox();
            this.bbiZoomIn = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.panelControl1 = new DevExpress.XtraEditors.PanelControl();
            this.btnView = new DevExpress.XtraEditors.SimpleButton();
            this.btnClear = new DevExpress.XtraEditors.SimpleButton();
            this.cmbMonth = new DevExpress.XtraEditors.ComboBoxEdit();
            this.cmbYear = new DevExpress.XtraEditors.ComboBoxEdit();
            this.txtBarcode = new DevExpress.XtraEditors.TextEdit();
            this.txtName = new DevExpress.XtraEditors.TextEdit();
            this.txtServiceNo = new DevExpress.XtraEditors.TextEdit();
            this.btnSummary = new DevExpress.XtraEditors.SimpleButton();
            this.labelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.picturePath = new DevExpress.XtraEditors.PictureEdit();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.standardReportDesigner1 = new DevExpress.XtraReports.UserDesigner.Native.StandardReportDesigner();
            this.reportDesigner1 = new DevExpress.XtraReports.UserDesigner.XRDesignMdiController(this.components);
            this.gcInquiry = new DevExpress.XtraGrid.GridControl();
            this.tblDataBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dAL_DS_Inguiry = new ExecutivesExtraHoursInquiry.DAL.DataSource.DAL_DS_Inguiry();
            this.gvInquiry = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colLoc = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colCdate = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colDay = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colClockIn = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colClockOut = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colDutyType = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemComboBox1 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.colExtraIn = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colExtraOut = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colHours = new DevExpress.XtraGrid.Columns.GridColumn();
            this.ExtraApprovedBy = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colEdate = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colEtype = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colFull = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colLate = new DevExpress.XtraGrid.Columns.GridColumn();
            this.Cont = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemCheckEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.ExtraCont = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemCheckEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.labelControl6 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl7 = new DevExpress.XtraEditors.LabelControl();
            this.pnlService = new DevExpress.XtraEditors.PanelControl();
            this.labelControl11 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl10 = new DevExpress.XtraEditors.LabelControl();
            this.gcmeter = new DevExpress.XtraGrid.GridControl();
            this.tblservicenoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gvmeter = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colv_service_no = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colv_name = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colv_barcode_no = new DevExpress.XtraGrid.Columns.GridColumn();
            this.behaviorManager1 = new DevExpress.Utils.Behaviors.BehaviorManager(this.components);
            this.labelControl8 = new DevExpress.XtraEditors.LabelControl();
            this.gcView = new DevExpress.XtraGrid.GridControl();
            this.tblviewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gvView = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colhev_extra_code = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colhev_extra_narration = new DevExpress.XtraGrid.Columns.GridColumn();
            this.ExtraDays = new DevExpress.XtraGrid.Columns.GridColumn();
            this.pnlView = new DevExpress.XtraEditors.PanelControl();
            this.lblsup = new DevExpress.XtraEditors.LabelControl();
            this.labelControl9 = new DevExpress.XtraEditors.LabelControl();
            ((System.ComponentModel.ISupportInitialize)(this.xrDesignBarManager1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrDesignDockManager1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.recentlyUsedItemsComboBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.designRepositoryItemComboBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.designRepositoryItemComboBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).BeginInit();
            this.panelControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cmbMonth.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmbYear.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBarcode.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtName.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtServiceNo.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picturePath.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.reportDesigner1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcInquiry)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblDataBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dAL_DS_Inguiry)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvInquiry)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pnlService)).BeginInit();
            this.pnlService.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gcmeter)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblservicenoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvmeter)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.behaviorManager1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblviewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pnlView)).BeginInit();
            this.pnlView.SuspendLayout();
            this.SuspendLayout();
            // 
            // xrDesignBarManager1
            // 
            this.xrDesignBarManager1.DockControls.Add(this.barDockControlTop);
            this.xrDesignBarManager1.DockControls.Add(this.barDockControlBottom);
            this.xrDesignBarManager1.DockControls.Add(this.barDockControlLeft);
            this.xrDesignBarManager1.DockControls.Add(this.barDockControlRight);
            this.xrDesignBarManager1.DockManager = this.xrDesignDockManager1;
            this.xrDesignBarManager1.FontNameBox = this.recentlyUsedItemsComboBox1;
            this.xrDesignBarManager1.FontNameEdit = this.beiFontName;
            this.xrDesignBarManager1.FontSizeBox = this.designRepositoryItemComboBox1;
            this.xrDesignBarManager1.FontSizeEdit = this.beiFontSize;
            this.xrDesignBarManager1.Form = this;
            this.xrDesignBarManager1.FormattingToolbar = null;
            this.xrDesignBarManager1.HintStaticItem = this.bsiHint;
            this.xrDesignBarManager1.ImageStream = ((DevExpress.Utils.ImageCollectionStreamer)(resources.GetObject("xrDesignBarManager1.ImageStream")));
            this.xrDesignBarManager1.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.beiFontName,
            this.beiFontSize,
            this.bbiFontBold,
            this.bbiFontItalic,
            this.bbiFontUnderline,
            this.bbiForeColor,
            this.bbiBackColor,
            this.bbiJustifyLeft,
            this.bbiJustifyCenter,
            this.bbiJustifyRight,
            this.bbiJustifyJustify,
            this.bbiAlignToGrid,
            this.bbiAlignLeft,
            this.bbiAlignVerticalCenters,
            this.bbiAlignRight,
            this.bbiAlignTop,
            this.bbiAlignHorizontalCenters,
            this.bbiAlignBottom,
            this.bbiSizeToControlWidth,
            this.bbiSizeToGrid,
            this.bbiSizeToControlHeight,
            this.bbiSizeToControl,
            this.bbiHorizSpaceMakeEqual,
            this.bbiHorizSpaceIncrease,
            this.bbiHorizSpaceDecrease,
            this.bbiHorizSpaceConcatenate,
            this.bbiVertSpaceMakeEqual,
            this.bbiVertSpaceIncrease,
            this.bbiVertSpaceDecrease,
            this.bbiVertSpaceConcatenate,
            this.bbiCenterHorizontally,
            this.bbiCenterVertically,
            this.bbiBringToFront,
            this.bbiSendToBack,
            this.bbiOpenFile,
            this.bbiCut,
            this.bbiCopy,
            this.bbiPaste,
            this.bbiUndo,
            this.bbiRedo,
            this.bsiHint,
            this.msiTabButtons,
            this.barReportTabButtonsListItem1,
            this.barSubItem1,
            this.xrBarToolbarsListItem1,
            this.barSubItem2,
            this.barDockPanelsListItem1,
            this.msiFormat,
            this.msiFont,
            this.msiJustify,
            this.msiAlign,
            this.msiSameSize,
            this.msiHorizontalSpacing,
            this.msiVerticalSpacing,
            this.bsiCenter,
            this.msiOrder,
            this.commandBarItem2,
            this.commandBarItem3,
            this.commandBarItem4,
            this.commandBarItem5,
            this.commandBarItem6,
            this.msiWindow,
            this.msiWindowInterface,
            this.commandBarItem8,
            this.commandBarItem9,
            this.commandBarItem10,
            this.msiWindows,
            this.commandBarItem11,
            this.bbiZoomOut,
            this.bbiZoom,
            this.bbiZoomIn});
            this.xrDesignBarManager1.LayoutToolbar = null;
            this.xrDesignBarManager1.MaxItemId = 76;
            this.xrDesignBarManager1.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.recentlyUsedItemsComboBox1,
            this.designRepositoryItemComboBox1,
            this.designRepositoryItemComboBox2});
            this.xrDesignBarManager1.Toolbar = null;
            this.xrDesignBarManager1.TransparentEditorsMode = DevExpress.Utils.DefaultBoolean.True;
            this.xrDesignBarManager1.Updates.AddRange(new string[] {
            "Toolbox"});
            this.xrDesignBarManager1.ZoomItem = this.bbiZoom;
            // 
            // barDockControlTop
            // 
            this.barDockControlTop.CausesValidation = false;
            this.barDockControlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.barDockControlTop.Location = new System.Drawing.Point(0, 0);
            this.barDockControlTop.Manager = this.xrDesignBarManager1;
            this.barDockControlTop.Size = new System.Drawing.Size(1151, 0);
            // 
            // barDockControlBottom
            // 
            this.barDockControlBottom.CausesValidation = false;
            this.barDockControlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.barDockControlBottom.Location = new System.Drawing.Point(0, 976);
            this.barDockControlBottom.Manager = this.xrDesignBarManager1;
            this.barDockControlBottom.Size = new System.Drawing.Size(1151, 0);
            // 
            // barDockControlLeft
            // 
            this.barDockControlLeft.CausesValidation = false;
            this.barDockControlLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.barDockControlLeft.Location = new System.Drawing.Point(0, 0);
            this.barDockControlLeft.Manager = this.xrDesignBarManager1;
            this.barDockControlLeft.Size = new System.Drawing.Size(0, 976);
            // 
            // barDockControlRight
            // 
            this.barDockControlRight.CausesValidation = false;
            this.barDockControlRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.barDockControlRight.Location = new System.Drawing.Point(1151, 0);
            this.barDockControlRight.Manager = this.xrDesignBarManager1;
            this.barDockControlRight.Size = new System.Drawing.Size(0, 976);
            // 
            // xrDesignDockManager1
            // 
            this.xrDesignDockManager1.Form = this;
            this.xrDesignDockManager1.ImageStream = ((DevExpress.Utils.ImageCollectionStreamer)(resources.GetObject("xrDesignDockManager1.ImageStream")));
            this.xrDesignDockManager1.MenuManager = this.xrDesignBarManager1;
            this.xrDesignDockManager1.TopZIndexControls.AddRange(new string[] {
            "DevExpress.XtraBars.BarDockControl",
            "DevExpress.XtraBars.StandaloneBarDockControl",
            "System.Windows.Forms.MenuStrip",
            "System.Windows.Forms.StatusStrip",
            "System.Windows.Forms.StatusBar",
            "DevExpress.XtraBars.Ribbon.RibbonStatusBar",
            "DevExpress.XtraBars.Ribbon.RibbonControl",
            "DevExpress.XtraBars.Navigation.OfficeNavigationBar",
            "DevExpress.XtraBars.Navigation.TileNavPane",
            "DevExpress.XtraBars.TabFormControl",
            "DevExpress.XtraBars.FluentDesignSystem.FluentDesignFormControl",
            "DevExpress.XtraBars.ToolbarForm.ToolbarFormControl"});
            // 
            // recentlyUsedItemsComboBox1
            // 
            this.recentlyUsedItemsComboBox1.AppearanceDropDown.Font = new System.Drawing.Font("Tahoma", 11.25F);
            this.recentlyUsedItemsComboBox1.AppearanceDropDown.Options.UseFont = true;
            this.recentlyUsedItemsComboBox1.AutoHeight = false;
            this.recentlyUsedItemsComboBox1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.recentlyUsedItemsComboBox1.Name = "recentlyUsedItemsComboBox1";
            // 
            // beiFontName
            // 
            this.beiFontName.Caption = "Font Name";
            this.beiFontName.Edit = this.recentlyUsedItemsComboBox1;
            this.beiFontName.EditWidth = 120;
            this.beiFontName.Hint = "Font Name";
            this.beiFontName.Id = 0;
            this.beiFontName.Name = "beiFontName";
            // 
            // designRepositoryItemComboBox1
            // 
            this.designRepositoryItemComboBox1.AutoHeight = false;
            this.designRepositoryItemComboBox1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.designRepositoryItemComboBox1.Name = "designRepositoryItemComboBox1";
            // 
            // beiFontSize
            // 
            this.beiFontSize.Caption = "Font Size";
            this.beiFontSize.Edit = this.designRepositoryItemComboBox1;
            this.beiFontSize.EditWidth = 55;
            this.beiFontSize.Hint = "Font Size";
            this.beiFontSize.Id = 1;
            this.beiFontSize.Name = "beiFontSize";
            // 
            // bsiHint
            // 
            this.bsiHint.AutoSize = DevExpress.XtraBars.BarStaticItemSize.Spring;
            this.bsiHint.Border = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.bsiHint.Id = 42;
            this.bsiHint.Name = "bsiHint";
            // 
            // bbiFontBold
            // 
            this.bbiFontBold.Caption = "&Bold";
            this.bbiFontBold.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.FontBold;
            this.bbiFontBold.Enabled = false;
            this.bbiFontBold.Hint = "Make the font bold";
            this.bbiFontBold.Id = 2;
            this.bbiFontBold.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.B));
            this.bbiFontBold.Name = "bbiFontBold";
            // 
            // bbiFontItalic
            // 
            this.bbiFontItalic.Caption = "&Italic";
            this.bbiFontItalic.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.FontItalic;
            this.bbiFontItalic.Enabled = false;
            this.bbiFontItalic.Hint = "Make the font italic";
            this.bbiFontItalic.Id = 3;
            this.bbiFontItalic.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.I));
            this.bbiFontItalic.Name = "bbiFontItalic";
            // 
            // bbiFontUnderline
            // 
            this.bbiFontUnderline.Caption = "&Underline";
            this.bbiFontUnderline.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.FontUnderline;
            this.bbiFontUnderline.Enabled = false;
            this.bbiFontUnderline.Hint = "Underline the font";
            this.bbiFontUnderline.Id = 4;
            this.bbiFontUnderline.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.U));
            this.bbiFontUnderline.Name = "bbiFontUnderline";
            // 
            // bbiForeColor
            // 
            this.bbiForeColor.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.bbiForeColor.Caption = "For&eground Color";
            this.bbiForeColor.CloseSubMenuOnClickMode = DevExpress.Utils.DefaultBoolean.False;
            this.bbiForeColor.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.ForeColor;
            this.bbiForeColor.Enabled = false;
            this.bbiForeColor.Hint = "Set the foreground color of the control";
            this.bbiForeColor.Id = 5;
            this.bbiForeColor.Name = "bbiForeColor";
            // 
            // bbiBackColor
            // 
            this.bbiBackColor.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.bbiBackColor.Caption = "Bac&kground Color";
            this.bbiBackColor.CloseSubMenuOnClickMode = DevExpress.Utils.DefaultBoolean.False;
            this.bbiBackColor.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.BackColor;
            this.bbiBackColor.Enabled = false;
            this.bbiBackColor.Hint = "Set the background color of the control";
            this.bbiBackColor.Id = 6;
            this.bbiBackColor.Name = "bbiBackColor";
            // 
            // bbiJustifyLeft
            // 
            this.bbiJustifyLeft.Caption = "&Left";
            this.bbiJustifyLeft.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.JustifyLeft;
            this.bbiJustifyLeft.Enabled = false;
            this.bbiJustifyLeft.Hint = "Align the control\'s text to the left";
            this.bbiJustifyLeft.Id = 7;
            this.bbiJustifyLeft.Name = "bbiJustifyLeft";
            // 
            // bbiJustifyCenter
            // 
            this.bbiJustifyCenter.Caption = "&Center";
            this.bbiJustifyCenter.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.JustifyCenter;
            this.bbiJustifyCenter.Enabled = false;
            this.bbiJustifyCenter.Hint = "Align the control\'s text to the center";
            this.bbiJustifyCenter.Id = 8;
            this.bbiJustifyCenter.Name = "bbiJustifyCenter";
            // 
            // bbiJustifyRight
            // 
            this.bbiJustifyRight.Caption = "&Rights";
            this.bbiJustifyRight.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.JustifyRight;
            this.bbiJustifyRight.Enabled = false;
            this.bbiJustifyRight.Hint = "Align the control\'s text to the right";
            this.bbiJustifyRight.Id = 9;
            this.bbiJustifyRight.Name = "bbiJustifyRight";
            // 
            // bbiJustifyJustify
            // 
            this.bbiJustifyJustify.Caption = "&Justify";
            this.bbiJustifyJustify.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.JustifyJustify;
            this.bbiJustifyJustify.Enabled = false;
            this.bbiJustifyJustify.Hint = "Justify the control\'s text";
            this.bbiJustifyJustify.Id = 10;
            this.bbiJustifyJustify.Name = "bbiJustifyJustify";
            // 
            // bbiAlignToGrid
            // 
            this.bbiAlignToGrid.Caption = "to &Grid";
            this.bbiAlignToGrid.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.AlignToGrid;
            this.bbiAlignToGrid.Enabled = false;
            this.bbiAlignToGrid.Hint = "Align the positions of the selected controls to the grid";
            this.bbiAlignToGrid.Id = 11;
            this.bbiAlignToGrid.Name = "bbiAlignToGrid";
            // 
            // bbiAlignLeft
            // 
            this.bbiAlignLeft.Caption = "&Lefts";
            this.bbiAlignLeft.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.AlignLeft;
            this.bbiAlignLeft.Enabled = false;
            this.bbiAlignLeft.Hint = "Left align the selected controls";
            this.bbiAlignLeft.Id = 12;
            this.bbiAlignLeft.Name = "bbiAlignLeft";
            // 
            // bbiAlignVerticalCenters
            // 
            this.bbiAlignVerticalCenters.Caption = "&Centers";
            this.bbiAlignVerticalCenters.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.AlignVerticalCenters;
            this.bbiAlignVerticalCenters.Enabled = false;
            this.bbiAlignVerticalCenters.Hint = "Align the centers of the selected controls vertically";
            this.bbiAlignVerticalCenters.Id = 13;
            this.bbiAlignVerticalCenters.Name = "bbiAlignVerticalCenters";
            // 
            // bbiAlignRight
            // 
            this.bbiAlignRight.Caption = "&Rights";
            this.bbiAlignRight.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.AlignRight;
            this.bbiAlignRight.Enabled = false;
            this.bbiAlignRight.Hint = "Right align the selected controls";
            this.bbiAlignRight.Id = 14;
            this.bbiAlignRight.Name = "bbiAlignRight";
            // 
            // bbiAlignTop
            // 
            this.bbiAlignTop.Caption = "&Tops";
            this.bbiAlignTop.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.AlignTop;
            this.bbiAlignTop.Enabled = false;
            this.bbiAlignTop.Hint = "Align the tops of the selected controls";
            this.bbiAlignTop.Id = 15;
            this.bbiAlignTop.Name = "bbiAlignTop";
            // 
            // bbiAlignHorizontalCenters
            // 
            this.bbiAlignHorizontalCenters.Caption = "&Middles";
            this.bbiAlignHorizontalCenters.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.AlignHorizontalCenters;
            this.bbiAlignHorizontalCenters.Enabled = false;
            this.bbiAlignHorizontalCenters.Hint = "Align the centers of the selected controls horizontally";
            this.bbiAlignHorizontalCenters.Id = 16;
            this.bbiAlignHorizontalCenters.Name = "bbiAlignHorizontalCenters";
            // 
            // bbiAlignBottom
            // 
            this.bbiAlignBottom.Caption = "&Bottoms";
            this.bbiAlignBottom.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.AlignBottom;
            this.bbiAlignBottom.Enabled = false;
            this.bbiAlignBottom.Hint = "Align the bottoms of the selected controls";
            this.bbiAlignBottom.Id = 17;
            this.bbiAlignBottom.Name = "bbiAlignBottom";
            // 
            // bbiSizeToControlWidth
            // 
            this.bbiSizeToControlWidth.Caption = "&Width";
            this.bbiSizeToControlWidth.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.SizeToControlWidth;
            this.bbiSizeToControlWidth.Enabled = false;
            this.bbiSizeToControlWidth.Hint = "Make the selected controls have the same width";
            this.bbiSizeToControlWidth.Id = 18;
            this.bbiSizeToControlWidth.Name = "bbiSizeToControlWidth";
            // 
            // bbiSizeToGrid
            // 
            this.bbiSizeToGrid.Caption = "Size to Gri&d";
            this.bbiSizeToGrid.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.SizeToGrid;
            this.bbiSizeToGrid.Enabled = false;
            this.bbiSizeToGrid.Hint = "Size the selected controls to the grid";
            this.bbiSizeToGrid.Id = 19;
            this.bbiSizeToGrid.Name = "bbiSizeToGrid";
            // 
            // bbiSizeToControlHeight
            // 
            this.bbiSizeToControlHeight.Caption = "&Height";
            this.bbiSizeToControlHeight.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.SizeToControlHeight;
            this.bbiSizeToControlHeight.Enabled = false;
            this.bbiSizeToControlHeight.Hint = "Make the selected controls have the same height";
            this.bbiSizeToControlHeight.Id = 20;
            this.bbiSizeToControlHeight.Name = "bbiSizeToControlHeight";
            // 
            // bbiSizeToControl
            // 
            this.bbiSizeToControl.Caption = "&Both";
            this.bbiSizeToControl.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.SizeToControl;
            this.bbiSizeToControl.Enabled = false;
            this.bbiSizeToControl.Hint = "Make the selected controls the same size";
            this.bbiSizeToControl.Id = 21;
            this.bbiSizeToControl.Name = "bbiSizeToControl";
            // 
            // bbiHorizSpaceMakeEqual
            // 
            this.bbiHorizSpaceMakeEqual.Caption = "Make &Equal";
            this.bbiHorizSpaceMakeEqual.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.HorizSpaceMakeEqual;
            this.bbiHorizSpaceMakeEqual.Enabled = false;
            this.bbiHorizSpaceMakeEqual.Hint = "Make the spacing between the selected controls equal";
            this.bbiHorizSpaceMakeEqual.Id = 22;
            this.bbiHorizSpaceMakeEqual.Name = "bbiHorizSpaceMakeEqual";
            // 
            // bbiHorizSpaceIncrease
            // 
            this.bbiHorizSpaceIncrease.Caption = "&Increase";
            this.bbiHorizSpaceIncrease.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.HorizSpaceIncrease;
            this.bbiHorizSpaceIncrease.Enabled = false;
            this.bbiHorizSpaceIncrease.Hint = "Increase the spacing between the selected controls";
            this.bbiHorizSpaceIncrease.Id = 23;
            this.bbiHorizSpaceIncrease.Name = "bbiHorizSpaceIncrease";
            // 
            // bbiHorizSpaceDecrease
            // 
            this.bbiHorizSpaceDecrease.Caption = "&Decrease";
            this.bbiHorizSpaceDecrease.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.HorizSpaceDecrease;
            this.bbiHorizSpaceDecrease.Enabled = false;
            this.bbiHorizSpaceDecrease.Hint = "Decrease the spacing between the selected controls";
            this.bbiHorizSpaceDecrease.Id = 24;
            this.bbiHorizSpaceDecrease.Name = "bbiHorizSpaceDecrease";
            // 
            // bbiHorizSpaceConcatenate
            // 
            this.bbiHorizSpaceConcatenate.Caption = "&Remove";
            this.bbiHorizSpaceConcatenate.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.HorizSpaceConcatenate;
            this.bbiHorizSpaceConcatenate.Enabled = false;
            this.bbiHorizSpaceConcatenate.Hint = "Remove the spacing between the selected controls";
            this.bbiHorizSpaceConcatenate.Id = 25;
            this.bbiHorizSpaceConcatenate.Name = "bbiHorizSpaceConcatenate";
            // 
            // bbiVertSpaceMakeEqual
            // 
            this.bbiVertSpaceMakeEqual.Caption = "Make &Equal";
            this.bbiVertSpaceMakeEqual.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.VertSpaceMakeEqual;
            this.bbiVertSpaceMakeEqual.Enabled = false;
            this.bbiVertSpaceMakeEqual.Hint = "Make the spacing between the selected controls equal";
            this.bbiVertSpaceMakeEqual.Id = 26;
            this.bbiVertSpaceMakeEqual.Name = "bbiVertSpaceMakeEqual";
            // 
            // bbiVertSpaceIncrease
            // 
            this.bbiVertSpaceIncrease.Caption = "&Increase";
            this.bbiVertSpaceIncrease.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.VertSpaceIncrease;
            this.bbiVertSpaceIncrease.Enabled = false;
            this.bbiVertSpaceIncrease.Hint = "Increase the spacing between the selected controls";
            this.bbiVertSpaceIncrease.Id = 27;
            this.bbiVertSpaceIncrease.Name = "bbiVertSpaceIncrease";
            // 
            // bbiVertSpaceDecrease
            // 
            this.bbiVertSpaceDecrease.Caption = "&Decrease";
            this.bbiVertSpaceDecrease.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.VertSpaceDecrease;
            this.bbiVertSpaceDecrease.Enabled = false;
            this.bbiVertSpaceDecrease.Hint = "Decrease the spacing between the selected controls";
            this.bbiVertSpaceDecrease.Id = 28;
            this.bbiVertSpaceDecrease.Name = "bbiVertSpaceDecrease";
            // 
            // bbiVertSpaceConcatenate
            // 
            this.bbiVertSpaceConcatenate.Caption = "&Remove";
            this.bbiVertSpaceConcatenate.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.VertSpaceConcatenate;
            this.bbiVertSpaceConcatenate.Enabled = false;
            this.bbiVertSpaceConcatenate.Hint = "Remove the spacing between the selected controls";
            this.bbiVertSpaceConcatenate.Id = 29;
            this.bbiVertSpaceConcatenate.Name = "bbiVertSpaceConcatenate";
            // 
            // bbiCenterHorizontally
            // 
            this.bbiCenterHorizontally.Caption = "&Horizontally";
            this.bbiCenterHorizontally.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.CenterHorizontally;
            this.bbiCenterHorizontally.Enabled = false;
            this.bbiCenterHorizontally.Hint = "Horizontally center the selected controls within a band";
            this.bbiCenterHorizontally.Id = 30;
            this.bbiCenterHorizontally.Name = "bbiCenterHorizontally";
            // 
            // bbiCenterVertically
            // 
            this.bbiCenterVertically.Caption = "&Vertically";
            this.bbiCenterVertically.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.CenterVertically;
            this.bbiCenterVertically.Enabled = false;
            this.bbiCenterVertically.Hint = "Vertically center the selected controls within a band";
            this.bbiCenterVertically.Id = 31;
            this.bbiCenterVertically.Name = "bbiCenterVertically";
            // 
            // bbiBringToFront
            // 
            this.bbiBringToFront.Caption = "&Bring to Front";
            this.bbiBringToFront.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.BringToFront;
            this.bbiBringToFront.Enabled = false;
            this.bbiBringToFront.Hint = "Bring the selected controls to the front";
            this.bbiBringToFront.Id = 32;
            this.bbiBringToFront.Name = "bbiBringToFront";
            // 
            // bbiSendToBack
            // 
            this.bbiSendToBack.Caption = "&Send to Back";
            this.bbiSendToBack.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.SendToBack;
            this.bbiSendToBack.Enabled = false;
            this.bbiSendToBack.Hint = "Move the selected controls to the back";
            this.bbiSendToBack.Id = 33;
            this.bbiSendToBack.Name = "bbiSendToBack";
            // 
            // bbiOpenFile
            // 
            this.bbiOpenFile.Caption = "&Open...";
            this.bbiOpenFile.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.OpenFile;
            this.bbiOpenFile.Enabled = false;
            this.bbiOpenFile.Hint = "Open a report";
            this.bbiOpenFile.Id = 35;
            this.bbiOpenFile.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O));
            this.bbiOpenFile.Name = "bbiOpenFile";
            // 
            // bbiCut
            // 
            this.bbiCut.Caption = "Cu&t";
            this.bbiCut.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.Cut;
            this.bbiCut.Enabled = false;
            this.bbiCut.Hint = "Delete the control and copy it to the clipboard";
            this.bbiCut.Id = 37;
            this.bbiCut.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.X));
            this.bbiCut.Name = "bbiCut";
            // 
            // bbiCopy
            // 
            this.bbiCopy.Caption = "&Copy";
            this.bbiCopy.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.Copy;
            this.bbiCopy.Enabled = false;
            this.bbiCopy.Hint = "Copy the control to the clipboard";
            this.bbiCopy.Id = 38;
            this.bbiCopy.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C));
            this.bbiCopy.Name = "bbiCopy";
            // 
            // bbiPaste
            // 
            this.bbiPaste.Caption = "&Paste";
            this.bbiPaste.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.Paste;
            this.bbiPaste.Enabled = false;
            this.bbiPaste.Hint = "Add the control from the clipboard";
            this.bbiPaste.Id = 39;
            this.bbiPaste.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.V));
            this.bbiPaste.Name = "bbiPaste";
            // 
            // bbiUndo
            // 
            this.bbiUndo.Caption = "&Undo";
            this.bbiUndo.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.Undo;
            this.bbiUndo.Enabled = false;
            this.bbiUndo.Hint = "Undo the last operation";
            this.bbiUndo.Id = 40;
            this.bbiUndo.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Z));
            this.bbiUndo.Name = "bbiUndo";
            // 
            // bbiRedo
            // 
            this.bbiRedo.Caption = "&Redo";
            this.bbiRedo.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.Redo;
            this.bbiRedo.Enabled = false;
            this.bbiRedo.Hint = "Redo the last operation";
            this.bbiRedo.Id = 41;
            this.bbiRedo.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Y));
            this.bbiRedo.Name = "bbiRedo";
            // 
            // msiTabButtons
            // 
            this.msiTabButtons.Caption = "&View";
            this.msiTabButtons.Id = 45;
            this.msiTabButtons.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.barReportTabButtonsListItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.barSubItem1, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.barSubItem2, true)});
            this.msiTabButtons.Name = "msiTabButtons";
            // 
            // barReportTabButtonsListItem1
            // 
            this.barReportTabButtonsListItem1.Caption = "Tab Buttons";
            this.barReportTabButtonsListItem1.Id = 46;
            this.barReportTabButtonsListItem1.Name = "barReportTabButtonsListItem1";
            // 
            // barSubItem1
            // 
            this.barSubItem1.Caption = "&Toolbars";
            this.barSubItem1.Id = 47;
            this.barSubItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.xrBarToolbarsListItem1)});
            this.barSubItem1.Name = "barSubItem1";
            // 
            // xrBarToolbarsListItem1
            // 
            this.xrBarToolbarsListItem1.Caption = "&Toolbars";
            this.xrBarToolbarsListItem1.Id = 48;
            this.xrBarToolbarsListItem1.Name = "xrBarToolbarsListItem1";
            // 
            // barSubItem2
            // 
            this.barSubItem2.Caption = "&Windows";
            this.barSubItem2.Id = 49;
            this.barSubItem2.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.barDockPanelsListItem1)});
            this.barSubItem2.Name = "barSubItem2";
            // 
            // barDockPanelsListItem1
            // 
            this.barDockPanelsListItem1.Caption = "&Windows";
            this.barDockPanelsListItem1.DockManager = null;
            this.barDockPanelsListItem1.Id = 50;
            this.barDockPanelsListItem1.Name = "barDockPanelsListItem1";
            this.barDockPanelsListItem1.ShowCustomizationItem = false;
            this.barDockPanelsListItem1.ShowDockPanels = true;
            this.barDockPanelsListItem1.ShowToolbars = false;
            // 
            // msiFormat
            // 
            this.msiFormat.Caption = "Fo&rmat";
            this.msiFormat.Id = 51;
            this.msiFormat.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiForeColor),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiBackColor),
            new DevExpress.XtraBars.LinkPersistInfo(this.msiFont, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.msiJustify),
            new DevExpress.XtraBars.LinkPersistInfo(this.msiAlign, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.msiSameSize),
            new DevExpress.XtraBars.LinkPersistInfo(this.msiHorizontalSpacing, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.msiVerticalSpacing),
            new DevExpress.XtraBars.LinkPersistInfo(this.bsiCenter, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.msiOrder, true)});
            this.msiFormat.Name = "msiFormat";
            // 
            // msiFont
            // 
            this.msiFont.Caption = "&Font";
            this.msiFont.Id = 52;
            this.msiFont.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiFontBold, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiFontItalic),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiFontUnderline)});
            this.msiFont.Name = "msiFont";
            // 
            // msiJustify
            // 
            this.msiJustify.Caption = "&Justify";
            this.msiJustify.Id = 53;
            this.msiJustify.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiJustifyLeft, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiJustifyCenter),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiJustifyRight),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiJustifyJustify)});
            this.msiJustify.Name = "msiJustify";
            // 
            // msiAlign
            // 
            this.msiAlign.Caption = "&Align";
            this.msiAlign.Id = 54;
            this.msiAlign.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiAlignLeft, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiAlignVerticalCenters),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiAlignRight),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiAlignTop, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiAlignHorizontalCenters),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiAlignBottom),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiAlignToGrid, true)});
            this.msiAlign.Name = "msiAlign";
            // 
            // msiSameSize
            // 
            this.msiSameSize.Caption = "&Make Same Size";
            this.msiSameSize.Id = 55;
            this.msiSameSize.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiSizeToControlWidth, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiSizeToGrid),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiSizeToControlHeight),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiSizeToControl)});
            this.msiSameSize.Name = "msiSameSize";
            // 
            // msiHorizontalSpacing
            // 
            this.msiHorizontalSpacing.Caption = "&Horizontal Spacing";
            this.msiHorizontalSpacing.Id = 56;
            this.msiHorizontalSpacing.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiHorizSpaceMakeEqual, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiHorizSpaceIncrease),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiHorizSpaceDecrease),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiHorizSpaceConcatenate)});
            this.msiHorizontalSpacing.Name = "msiHorizontalSpacing";
            // 
            // msiVerticalSpacing
            // 
            this.msiVerticalSpacing.Caption = "&Vertical Spacing";
            this.msiVerticalSpacing.Id = 57;
            this.msiVerticalSpacing.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiVertSpaceMakeEqual, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiVertSpaceIncrease),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiVertSpaceDecrease),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiVertSpaceConcatenate)});
            this.msiVerticalSpacing.Name = "msiVerticalSpacing";
            // 
            // bsiCenter
            // 
            this.bsiCenter.Caption = "&Center in Form";
            this.bsiCenter.Id = 58;
            this.bsiCenter.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiCenterHorizontally, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiCenterVertically)});
            this.bsiCenter.Name = "bsiCenter";
            // 
            // msiOrder
            // 
            this.msiOrder.Caption = "&Order";
            this.msiOrder.Id = 59;
            this.msiOrder.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiBringToFront, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiSendToBack)});
            this.msiOrder.Name = "msiOrder";
            // 
            // commandBarItem2
            // 
            this.commandBarItem2.Caption = "New via &Wizard...";
            this.commandBarItem2.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.NewReportWizard;
            this.commandBarItem2.Enabled = false;
            this.commandBarItem2.Hint = "Create a new report using the Wizard";
            this.commandBarItem2.Id = 60;
            this.commandBarItem2.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.W));
            this.commandBarItem2.Name = "commandBarItem2";
            // 
            // commandBarItem3
            // 
            this.commandBarItem3.Caption = "Save &As...";
            this.commandBarItem3.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.SaveFileAs;
            this.commandBarItem3.Enabled = false;
            this.commandBarItem3.Hint = "Save the report with a new name";
            this.commandBarItem3.Id = 61;
            this.commandBarItem3.Name = "commandBarItem3";
            // 
            // commandBarItem4
            // 
            this.commandBarItem4.Caption = "E&xit";
            this.commandBarItem4.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.Exit;
            this.commandBarItem4.Enabled = false;
            this.commandBarItem4.Hint = "Close the designer";
            this.commandBarItem4.Id = 62;
            this.commandBarItem4.Name = "commandBarItem4";
            // 
            // commandBarItem5
            // 
            this.commandBarItem5.Caption = "&Delete";
            this.commandBarItem5.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.Delete;
            this.commandBarItem5.Enabled = false;
            this.commandBarItem5.Hint = "Delete the control";
            this.commandBarItem5.Id = 63;
            this.commandBarItem5.Name = "commandBarItem5";
            // 
            // commandBarItem6
            // 
            this.commandBarItem6.Caption = "Select &All";
            this.commandBarItem6.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.SelectAll;
            this.commandBarItem6.Enabled = false;
            this.commandBarItem6.Hint = "Select all the controls in the document";
            this.commandBarItem6.Id = 64;
            this.commandBarItem6.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.A));
            this.commandBarItem6.Name = "commandBarItem6";
            // 
            // msiWindow
            // 
            this.msiWindow.Caption = "&Window";
            this.msiWindow.Id = 66;
            this.msiWindow.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.msiWindowInterface, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.commandBarItem8),
            new DevExpress.XtraBars.LinkPersistInfo(this.commandBarItem9),
            new DevExpress.XtraBars.LinkPersistInfo(this.commandBarItem10),
            new DevExpress.XtraBars.LinkPersistInfo(this.msiWindows, true)});
            this.msiWindow.Name = "msiWindow";
            // 
            // msiWindowInterface
            // 
            this.msiWindowInterface.BindableChecked = true;
            this.msiWindowInterface.Caption = "&Tabbed Interface";
            this.msiWindowInterface.Checked = true;
            this.msiWindowInterface.CheckedCommand = DevExpress.XtraReports.UserDesigner.ReportCommand.ShowTabbedInterface;
            this.msiWindowInterface.Enabled = false;
            this.msiWindowInterface.Hint = "Switch between tabbed and window MDI layout modes";
            this.msiWindowInterface.Id = 67;
            this.msiWindowInterface.Name = "msiWindowInterface";
            this.msiWindowInterface.UncheckedCommand = DevExpress.XtraReports.UserDesigner.ReportCommand.ShowWindowInterface;
            // 
            // commandBarItem8
            // 
            this.commandBarItem8.Caption = "&Cascade";
            this.commandBarItem8.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.MdiCascade;
            this.commandBarItem8.Enabled = false;
            this.commandBarItem8.Hint = "Arrange all open documents cascaded, so that they overlap each other";
            this.commandBarItem8.Id = 68;
            this.commandBarItem8.Name = "commandBarItem8";
            // 
            // commandBarItem9
            // 
            this.commandBarItem9.Caption = "Tile &Horizontal";
            this.commandBarItem9.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.MdiTileHorizontal;
            this.commandBarItem9.Enabled = false;
            this.commandBarItem9.Hint = "Arrange all open documents from top to bottom";
            this.commandBarItem9.Id = 69;
            this.commandBarItem9.Name = "commandBarItem9";
            // 
            // commandBarItem10
            // 
            this.commandBarItem10.Caption = "Tile &Vertical";
            this.commandBarItem10.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.MdiTileVertical;
            this.commandBarItem10.Enabled = false;
            this.commandBarItem10.Hint = "Arrange all open documents from left to right";
            this.commandBarItem10.Id = 70;
            this.commandBarItem10.Name = "commandBarItem10";
            // 
            // msiWindows
            // 
            this.msiWindows.Caption = "Windows";
            this.msiWindows.Id = 71;
            this.msiWindows.Name = "msiWindows";
            // 
            // commandBarItem11
            // 
            this.commandBarItem11.Caption = "&Close";
            this.commandBarItem11.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.Close;
            this.commandBarItem11.Enabled = false;
            this.commandBarItem11.Hint = "Close the report";
            this.commandBarItem11.Id = 72;
            this.commandBarItem11.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.F4));
            this.commandBarItem11.Name = "commandBarItem11";
            // 
            // bbiZoomOut
            // 
            this.bbiZoomOut.Caption = "Zoom Out";
            this.bbiZoomOut.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.ZoomOut;
            this.bbiZoomOut.Enabled = false;
            this.bbiZoomOut.Hint = "Zoom out the design surface";
            this.bbiZoomOut.Id = 73;
            this.bbiZoomOut.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Subtract));
            this.bbiZoomOut.Name = "bbiZoomOut";
            // 
            // bbiZoom
            // 
            this.bbiZoom.Caption = "Zoom";
            this.bbiZoom.Edit = this.designRepositoryItemComboBox2;
            this.bbiZoom.EditWidth = 70;
            this.bbiZoom.Enabled = false;
            this.bbiZoom.Hint = "Select or input the zoom factor";
            this.bbiZoom.Id = 74;
            this.bbiZoom.Name = "bbiZoom";
            // 
            // designRepositoryItemComboBox2
            // 
            this.designRepositoryItemComboBox2.AutoComplete = false;
            this.designRepositoryItemComboBox2.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.designRepositoryItemComboBox2.Name = "designRepositoryItemComboBox2";
            // 
            // bbiZoomIn
            // 
            this.bbiZoomIn.Caption = "Zoom In";
            this.bbiZoomIn.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.ZoomIn;
            this.bbiZoomIn.Enabled = false;
            this.bbiZoomIn.Hint = "Zoom in the design surface";
            this.bbiZoomIn.Id = 75;
            this.bbiZoomIn.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Add));
            this.bbiZoomIn.Name = "bbiZoomIn";
            // 
            // panelControl1
            // 
            this.panelControl1.Controls.Add(this.btnView);
            this.panelControl1.Controls.Add(this.btnClear);
            this.panelControl1.Controls.Add(this.cmbMonth);
            this.panelControl1.Controls.Add(this.cmbYear);
            this.panelControl1.Controls.Add(this.txtBarcode);
            this.panelControl1.Controls.Add(this.txtName);
            this.panelControl1.Controls.Add(this.txtServiceNo);
            this.panelControl1.Controls.Add(this.btnSummary);
            this.panelControl1.Controls.Add(this.labelControl5);
            this.panelControl1.Controls.Add(this.picturePath);
            this.panelControl1.Controls.Add(this.labelControl4);
            this.panelControl1.Controls.Add(this.labelControl3);
            this.panelControl1.Controls.Add(this.labelControl2);
            this.panelControl1.Controls.Add(this.labelControl1);
            this.panelControl1.Location = new System.Drawing.Point(1, 3);
            this.panelControl1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelControl1.Name = "panelControl1";
            this.panelControl1.Size = new System.Drawing.Size(1146, 105);
            this.panelControl1.TabIndex = 0;
            // 
            // btnView
            // 
            this.btnView.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.btnView.Appearance.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnView.Appearance.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnView.Appearance.ForeColor = System.Drawing.Color.White;
            this.btnView.Appearance.Options.UseBackColor = true;
            this.btnView.Appearance.Options.UseFont = true;
            this.btnView.Appearance.Options.UseForeColor = true;
            this.btnView.Location = new System.Drawing.Point(869, 61);
            this.btnView.Name = "btnView";
            this.btnView.Size = new System.Drawing.Size(78, 29);
            this.btnView.TabIndex = 250;
            this.btnView.Text = "Summary";
            this.btnView.Click += new System.EventHandler(this.btnView_Click);
            // 
            // btnClear
            // 
            this.btnClear.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClear.Appearance.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnClear.Appearance.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.Appearance.FontStyleDelta = System.Drawing.FontStyle.Bold;
            this.btnClear.Appearance.ForeColor = System.Drawing.Color.White;
            this.btnClear.Appearance.Options.UseBackColor = true;
            this.btnClear.Appearance.Options.UseFont = true;
            this.btnClear.Appearance.Options.UseForeColor = true;
            this.btnClear.AppearanceDisabled.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnClear.AppearanceDisabled.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.AppearanceDisabled.FontStyleDelta = System.Drawing.FontStyle.Bold;
            this.btnClear.AppearanceDisabled.ForeColor = System.Drawing.Color.White;
            this.btnClear.AppearanceDisabled.Options.UseBackColor = true;
            this.btnClear.AppearanceDisabled.Options.UseFont = true;
            this.btnClear.AppearanceDisabled.Options.UseForeColor = true;
            this.btnClear.AppearanceHovered.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnClear.AppearanceHovered.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.AppearanceHovered.FontStyleDelta = System.Drawing.FontStyle.Bold;
            this.btnClear.AppearanceHovered.ForeColor = System.Drawing.Color.White;
            this.btnClear.AppearanceHovered.Options.UseBackColor = true;
            this.btnClear.AppearanceHovered.Options.UseFont = true;
            this.btnClear.AppearanceHovered.Options.UseForeColor = true;
            this.btnClear.AppearancePressed.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnClear.AppearancePressed.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.AppearancePressed.FontStyleDelta = System.Drawing.FontStyle.Bold;
            this.btnClear.AppearancePressed.ForeColor = System.Drawing.Color.White;
            this.btnClear.AppearancePressed.Options.UseBackColor = true;
            this.btnClear.AppearancePressed.Options.UseFont = true;
            this.btnClear.AppearancePressed.Options.UseForeColor = true;
            this.btnClear.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnClear.ImageOptions.Image")));
            this.btnClear.Location = new System.Drawing.Point(953, 60);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(70, 30);
            this.btnClear.TabIndex = 249;
            this.btnClear.Text = "Clear";
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // cmbMonth
            // 
            this.cmbMonth.Location = new System.Drawing.Point(913, 17);
            this.cmbMonth.MenuManager = this.xrDesignBarManager1;
            this.cmbMonth.Name = "cmbMonth";
            this.cmbMonth.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbMonth.Properties.Appearance.Options.UseFont = true;
            this.cmbMonth.Properties.Appearance.Options.UseTextOptions = true;
            this.cmbMonth.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.cmbMonth.Properties.Appearance.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.cmbMonth.Properties.Appearance.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.cmbMonth.Properties.AppearanceDropDown.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbMonth.Properties.AppearanceDropDown.Options.UseFont = true;
            this.cmbMonth.Properties.AppearanceDropDown.Options.UseTextOptions = true;
            this.cmbMonth.Properties.AppearanceDropDown.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.cmbMonth.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cmbMonth.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
            this.cmbMonth.Size = new System.Drawing.Size(110, 24);
            this.cmbMonth.TabIndex = 18;
            this.cmbMonth.SelectedIndexChanged += new System.EventHandler(this.cmbMonth_SelectedIndexChanged);
            // 
            // cmbYear
            // 
            this.cmbYear.Location = new System.Drawing.Point(751, 17);
            this.cmbYear.MenuManager = this.xrDesignBarManager1;
            this.cmbYear.Name = "cmbYear";
            this.cmbYear.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbYear.Properties.Appearance.Options.UseFont = true;
            this.cmbYear.Properties.Appearance.Options.UseTextOptions = true;
            this.cmbYear.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.cmbYear.Properties.Appearance.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.cmbYear.Properties.Appearance.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.cmbYear.Properties.AppearanceDropDown.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbYear.Properties.AppearanceDropDown.Options.UseFont = true;
            this.cmbYear.Properties.AppearanceDropDown.Options.UseTextOptions = true;
            this.cmbYear.Properties.AppearanceDropDown.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.cmbYear.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cmbYear.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
            this.cmbYear.Size = new System.Drawing.Size(100, 24);
            this.cmbYear.TabIndex = 17;
            // 
            // txtBarcode
            // 
            this.txtBarcode.Location = new System.Drawing.Point(536, 20);
            this.txtBarcode.Name = "txtBarcode";
            this.txtBarcode.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBarcode.Properties.Appearance.Options.UseFont = true;
            this.txtBarcode.Properties.Appearance.Options.UseTextOptions = true;
            this.txtBarcode.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.txtBarcode.Properties.Appearance.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.txtBarcode.Properties.AppearanceReadOnly.BackColor = System.Drawing.Color.White;
            this.txtBarcode.Properties.AppearanceReadOnly.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBarcode.Properties.AppearanceReadOnly.Options.UseBackColor = true;
            this.txtBarcode.Properties.AppearanceReadOnly.Options.UseFont = true;
            this.txtBarcode.Properties.ReadOnly = true;
            this.txtBarcode.Size = new System.Drawing.Size(84, 24);
            this.txtBarcode.TabIndex = 7;
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(243, 20);
            this.txtName.Name = "txtName";
            this.txtName.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtName.Properties.Appearance.Options.UseFont = true;
            this.txtName.Properties.Appearance.Options.UseTextOptions = true;
            this.txtName.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.txtName.Properties.Appearance.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.txtName.Properties.AppearanceReadOnly.BackColor = System.Drawing.Color.White;
            this.txtName.Properties.AppearanceReadOnly.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtName.Properties.AppearanceReadOnly.Options.UseBackColor = true;
            this.txtName.Properties.AppearanceReadOnly.Options.UseFont = true;
            this.txtName.Properties.ReadOnly = true;
            this.txtName.Size = new System.Drawing.Size(225, 24);
            this.txtName.TabIndex = 6;
            // 
            // txtServiceNo
            // 
            this.txtServiceNo.Location = new System.Drawing.Point(88, 17);
            this.txtServiceNo.Name = "txtServiceNo";
            this.txtServiceNo.Properties.Appearance.BackColor = System.Drawing.Color.LightYellow;
            this.txtServiceNo.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtServiceNo.Properties.Appearance.Options.UseBackColor = true;
            this.txtServiceNo.Properties.Appearance.Options.UseFont = true;
            this.txtServiceNo.Properties.Appearance.Options.UseTextOptions = true;
            this.txtServiceNo.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.txtServiceNo.Properties.Appearance.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.txtServiceNo.Properties.ReadOnly = true;
            this.txtServiceNo.Size = new System.Drawing.Size(100, 24);
            this.txtServiceNo.TabIndex = 5;
            this.txtServiceNo.EditValueChanged += new System.EventHandler(this.txtServiceNo_EditValueChanged);
            this.txtServiceNo.DoubleClick += new System.EventHandler(this.txtServiceNo_DoubleClick);
            this.txtServiceNo.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.txtServiceNo_MouseDoubleClick);
            // 
            // btnSummary
            // 
            this.btnSummary.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.btnSummary.Appearance.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnSummary.Appearance.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSummary.Appearance.ForeColor = System.Drawing.Color.White;
            this.btnSummary.Appearance.Options.UseBackColor = true;
            this.btnSummary.Appearance.Options.UseFont = true;
            this.btnSummary.Appearance.Options.UseForeColor = true;
            this.btnSummary.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnSummary.ImageOptions.Image")));
            this.btnSummary.Location = new System.Drawing.Point(785, 61);
            this.btnSummary.Name = "btnSummary";
            this.btnSummary.Size = new System.Drawing.Size(78, 29);
            this.btnSummary.TabIndex = 17;
            this.btnSummary.Text = "Load";
            this.btnSummary.Click += new System.EventHandler(this.btnSummary_Click);
            // 
            // labelControl5
            // 
            this.labelControl5.Appearance.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl5.Appearance.Options.UseFont = true;
            this.labelControl5.Location = new System.Drawing.Point(857, 20);
            this.labelControl5.Name = "labelControl5";
            this.labelControl5.Size = new System.Drawing.Size(50, 17);
            this.labelControl5.TabIndex = 4;
            this.labelControl5.Text = "Month -";
            // 
            // picturePath
            // 
            this.picturePath.Location = new System.Drawing.Point(1035, 5);
            this.picturePath.MenuManager = this.xrDesignBarManager1;
            this.picturePath.Name = "picturePath";
            this.picturePath.Properties.ShowCameraMenuItem = DevExpress.XtraEditors.Controls.CameraMenuItemVisibility.Auto;
            this.picturePath.Properties.SizeMode = DevExpress.XtraEditors.Controls.PictureSizeMode.Squeeze;
            this.picturePath.Size = new System.Drawing.Size(103, 91);
            this.picturePath.TabIndex = 14;
            // 
            // labelControl4
            // 
            this.labelControl4.Appearance.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl4.Appearance.Options.UseFont = true;
            this.labelControl4.Location = new System.Drawing.Point(709, 20);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(36, 17);
            this.labelControl4.TabIndex = 3;
            this.labelControl4.Text = "Year -";
            // 
            // labelControl3
            // 
            this.labelControl3.Appearance.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl3.Appearance.Options.UseFont = true;
            this.labelControl3.Location = new System.Drawing.Point(474, 20);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(58, 17);
            this.labelControl3.TabIndex = 2;
            this.labelControl3.Text = "Barcode -";
            // 
            // labelControl2
            // 
            this.labelControl2.Appearance.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl2.Appearance.Options.UseFont = true;
            this.labelControl2.Location = new System.Drawing.Point(194, 20);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(45, 17);
            this.labelControl2.TabIndex = 1;
            this.labelControl2.Text = "Name -";
            // 
            // labelControl1
            // 
            this.labelControl1.Appearance.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl1.Appearance.Options.UseFont = true;
            this.labelControl1.Location = new System.Drawing.Point(11, 17);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(73, 17);
            this.labelControl1.TabIndex = 0;
            this.labelControl1.Text = "Service No -";
            // 
            // reportDesigner1
            // 
            this.reportDesigner1.ContainerControl = null;
            xrDesignPanelListener1.DesignControl = this.xrDesignBarManager1;
            xrDesignPanelListener2.DesignControl = this.xrDesignDockManager1;
            this.reportDesigner1.DesignPanelListeners.AddRange(new DevExpress.XtraReports.UserDesigner.XRDesignPanelListener[] {
            xrDesignPanelListener1,
            xrDesignPanelListener2});
            this.reportDesigner1.Form = this;
            // 
            // gcInquiry
            // 
            this.gcInquiry.DataSource = this.tblDataBindingSource;
            this.gcInquiry.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gcInquiry.Location = new System.Drawing.Point(3, 105);
            this.gcInquiry.MainView = this.gvInquiry;
            this.gcInquiry.MenuManager = this.xrDesignBarManager1;
            this.gcInquiry.Name = "gcInquiry";
            this.gcInquiry.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemComboBox1,
            this.repositoryItemCheckEdit1,
            this.repositoryItemCheckEdit2});
            this.gcInquiry.Size = new System.Drawing.Size(1144, 859);
            this.gcInquiry.TabIndex = 15;
            this.gcInquiry.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gvInquiry,
            this.gridView1});
            // 
            // tblDataBindingSource
            // 
            this.tblDataBindingSource.DataMember = "tbl_Data";
            this.tblDataBindingSource.DataSource = this.dAL_DS_Inguiry;
            // 
            // dAL_DS_Inguiry
            // 
            this.dAL_DS_Inguiry.DataSetName = "DAL_DS_Inguiry";
            this.dAL_DS_Inguiry.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // gvInquiry
            // 
            this.gvInquiry.Appearance.FooterPanel.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gvInquiry.Appearance.FooterPanel.Options.UseFont = true;
            this.gvInquiry.ColumnPanelRowHeight = 49;
            this.gvInquiry.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colLoc,
            this.colCdate,
            this.colDay,
            this.colClockIn,
            this.colClockOut,
            this.colDutyType,
            this.colExtraIn,
            this.colExtraOut,
            this.colHours,
            this.ExtraApprovedBy,
            this.colEdate,
            this.colEtype,
            this.colFull,
            this.colLate,
            this.Cont,
            this.ExtraCont});
            this.gvInquiry.GridControl = this.gcInquiry;
            this.gvInquiry.GroupRowHeight = 30;
            this.gvInquiry.Name = "gvInquiry";
            this.gvInquiry.OptionsDetail.EnableMasterViewMode = false;
            this.gvInquiry.OptionsFind.AlwaysVisible = true;
            this.gvInquiry.OptionsPrint.EnableAppearanceEvenRow = true;
            this.gvInquiry.OptionsView.ShowFooter = true;
            this.gvInquiry.OptionsView.ShowGroupPanel = false;
            this.gvInquiry.OptionsView.ShowHorizontalLines = DevExpress.Utils.DefaultBoolean.True;
            this.gvInquiry.OptionsView.ShowIndicator = false;
            this.gvInquiry.RowHeight = 26;
            // 
            // colLoc
            // 
            this.colLoc.AppearanceCell.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colLoc.AppearanceCell.Options.UseFont = true;
            this.colLoc.AppearanceCell.Options.UseTextOptions = true;
            this.colLoc.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colLoc.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colLoc.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colLoc.AppearanceHeader.Options.UseFont = true;
            this.colLoc.AppearanceHeader.Options.UseTextOptions = true;
            this.colLoc.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colLoc.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.colLoc.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colLoc.Caption = "Loc";
            this.colLoc.FieldName = "had_loc_code";
            this.colLoc.Name = "colLoc";
            this.colLoc.OptionsColumn.AllowEdit = false;
            this.colLoc.OptionsColumn.ReadOnly = true;
            this.colLoc.Visible = true;
            this.colLoc.VisibleIndex = 0;
            this.colLoc.Width = 50;
            // 
            // colCdate
            // 
            this.colCdate.AppearanceCell.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colCdate.AppearanceCell.Options.UseFont = true;
            this.colCdate.AppearanceCell.Options.UseTextOptions = true;
            this.colCdate.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colCdate.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colCdate.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colCdate.AppearanceHeader.Options.UseFont = true;
            this.colCdate.AppearanceHeader.Options.UseTextOptions = true;
            this.colCdate.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colCdate.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.colCdate.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colCdate.Caption = "Clock Date";
            this.colCdate.DisplayFormat.FormatString = "dd/MM/yyyy";
            this.colCdate.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.colCdate.FieldName = "had_date";
            this.colCdate.Name = "colCdate";
            this.colCdate.OptionsColumn.AllowEdit = false;
            this.colCdate.OptionsColumn.ReadOnly = true;
            this.colCdate.Visible = true;
            this.colCdate.VisibleIndex = 1;
            this.colCdate.Width = 73;
            // 
            // colDay
            // 
            this.colDay.AppearanceCell.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colDay.AppearanceCell.Options.UseFont = true;
            this.colDay.AppearanceCell.Options.UseTextOptions = true;
            this.colDay.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colDay.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colDay.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colDay.AppearanceHeader.Options.UseFont = true;
            this.colDay.AppearanceHeader.Options.UseTextOptions = true;
            this.colDay.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colDay.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.colDay.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colDay.Caption = "Clock Day";
            this.colDay.FieldName = "had_day";
            this.colDay.Name = "colDay";
            this.colDay.OptionsColumn.AllowEdit = false;
            this.colDay.OptionsColumn.ReadOnly = true;
            this.colDay.Visible = true;
            this.colDay.VisibleIndex = 2;
            this.colDay.Width = 69;
            // 
            // colClockIn
            // 
            this.colClockIn.AppearanceCell.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colClockIn.AppearanceCell.Options.UseFont = true;
            this.colClockIn.AppearanceCell.Options.UseTextOptions = true;
            this.colClockIn.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colClockIn.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colClockIn.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colClockIn.AppearanceHeader.Options.UseFont = true;
            this.colClockIn.AppearanceHeader.Options.UseTextOptions = true;
            this.colClockIn.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colClockIn.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.colClockIn.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colClockIn.Caption = "Clock In";
            this.colClockIn.DisplayFormat.FormatString = "dd/MM/yyyy";
            this.colClockIn.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.colClockIn.FieldName = "had_clock_in";
            this.colClockIn.Name = "colClockIn";
            this.colClockIn.OptionsColumn.AllowEdit = false;
            this.colClockIn.OptionsColumn.ReadOnly = true;
            this.colClockIn.Visible = true;
            this.colClockIn.VisibleIndex = 3;
            this.colClockIn.Width = 108;
            // 
            // colClockOut
            // 
            this.colClockOut.AppearanceCell.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colClockOut.AppearanceCell.Options.UseFont = true;
            this.colClockOut.AppearanceCell.Options.UseTextOptions = true;
            this.colClockOut.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colClockOut.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colClockOut.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colClockOut.AppearanceHeader.Options.UseFont = true;
            this.colClockOut.AppearanceHeader.Options.UseTextOptions = true;
            this.colClockOut.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colClockOut.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.colClockOut.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colClockOut.Caption = "Clock Out";
            this.colClockOut.DisplayFormat.FormatString = "dd/MM/yyyy";
            this.colClockOut.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.colClockOut.FieldName = "had_clock_out";
            this.colClockOut.Name = "colClockOut";
            this.colClockOut.OptionsColumn.AllowEdit = false;
            this.colClockOut.OptionsColumn.ReadOnly = true;
            this.colClockOut.Visible = true;
            this.colClockOut.VisibleIndex = 5;
            this.colClockOut.Width = 111;
            // 
            // colDutyType
            // 
            this.colDutyType.AppearanceCell.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colDutyType.AppearanceCell.Options.UseFont = true;
            this.colDutyType.AppearanceCell.Options.UseTextOptions = true;
            this.colDutyType.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colDutyType.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colDutyType.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colDutyType.AppearanceHeader.Options.UseFont = true;
            this.colDutyType.AppearanceHeader.Options.UseTextOptions = true;
            this.colDutyType.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colDutyType.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.colDutyType.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colDutyType.Caption = "Duty Type";
            this.colDutyType.ColumnEdit = this.repositoryItemComboBox1;
            this.colDutyType.FieldName = "duty_type";
            this.colDutyType.Name = "colDutyType";
            this.colDutyType.Visible = true;
            this.colDutyType.VisibleIndex = 6;
            this.colDutyType.Width = 67;
            // 
            // repositoryItemComboBox1
            // 
            this.repositoryItemComboBox1.AutoHeight = false;
            this.repositoryItemComboBox1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox1.Items.AddRange(new object[] {
            "Extra Hours",
            "Duty Roster"});
            this.repositoryItemComboBox1.Name = "repositoryItemComboBox1";
            this.repositoryItemComboBox1.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
            // 
            // colExtraIn
            // 
            this.colExtraIn.AppearanceCell.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colExtraIn.AppearanceCell.Options.UseFont = true;
            this.colExtraIn.AppearanceCell.Options.UseTextOptions = true;
            this.colExtraIn.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colExtraIn.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colExtraIn.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colExtraIn.AppearanceHeader.Options.UseFont = true;
            this.colExtraIn.AppearanceHeader.Options.UseTextOptions = true;
            this.colExtraIn.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colExtraIn.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.colExtraIn.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colExtraIn.Caption = "Extra Hours In";
            this.colExtraIn.FieldName = "extra_in";
            this.colExtraIn.Name = "colExtraIn";
            this.colExtraIn.OptionsColumn.ReadOnly = true;
            this.colExtraIn.Visible = true;
            this.colExtraIn.VisibleIndex = 7;
            this.colExtraIn.Width = 68;
            // 
            // colExtraOut
            // 
            this.colExtraOut.AppearanceCell.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colExtraOut.AppearanceCell.Options.UseFont = true;
            this.colExtraOut.AppearanceCell.Options.UseTextOptions = true;
            this.colExtraOut.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colExtraOut.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colExtraOut.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colExtraOut.AppearanceHeader.Options.UseFont = true;
            this.colExtraOut.AppearanceHeader.Options.UseTextOptions = true;
            this.colExtraOut.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colExtraOut.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.colExtraOut.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colExtraOut.Caption = "Extra Hours Out";
            this.colExtraOut.FieldName = "extra_out";
            this.colExtraOut.Name = "colExtraOut";
            this.colExtraOut.OptionsColumn.AllowEdit = false;
            this.colExtraOut.OptionsColumn.ReadOnly = true;
            this.colExtraOut.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Custom, "ExtraOut", "Total Extra Hours -")});
            this.colExtraOut.Visible = true;
            this.colExtraOut.VisibleIndex = 9;
            this.colExtraOut.Width = 139;
            // 
            // colHours
            // 
            this.colHours.AppearanceCell.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colHours.AppearanceCell.Options.UseFont = true;
            this.colHours.AppearanceCell.Options.UseTextOptions = true;
            this.colHours.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colHours.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colHours.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colHours.AppearanceHeader.Options.UseFont = true;
            this.colHours.AppearanceHeader.Options.UseTextOptions = true;
            this.colHours.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colHours.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.colHours.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colHours.Caption = "Extra Hours";
            this.colHours.FieldName = "had_endex_hours";
            this.colHours.Name = "colHours";
            this.colHours.OptionsColumn.AllowEdit = false;
            this.colHours.OptionsColumn.ReadOnly = true;
            this.colHours.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "Hours", "{0:0.##}")});
            this.colHours.Visible = true;
            this.colHours.VisibleIndex = 10;
            this.colHours.Width = 60;
            // 
            // ExtraApprovedBy
            // 
            this.ExtraApprovedBy.AppearanceCell.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExtraApprovedBy.AppearanceCell.Options.UseFont = true;
            this.ExtraApprovedBy.AppearanceCell.Options.UseTextOptions = true;
            this.ExtraApprovedBy.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.ExtraApprovedBy.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.ExtraApprovedBy.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExtraApprovedBy.AppearanceHeader.Options.UseFont = true;
            this.ExtraApprovedBy.AppearanceHeader.Options.UseTextOptions = true;
            this.ExtraApprovedBy.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.ExtraApprovedBy.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.ExtraApprovedBy.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.ExtraApprovedBy.Caption = "Extra Approved By";
            this.ExtraApprovedBy.FieldName = "extra_approved_name";
            this.ExtraApprovedBy.Name = "ExtraApprovedBy";
            this.ExtraApprovedBy.OptionsColumn.AllowEdit = false;
            this.ExtraApprovedBy.OptionsColumn.ReadOnly = true;
            this.ExtraApprovedBy.Visible = true;
            this.ExtraApprovedBy.VisibleIndex = 11;
            this.ExtraApprovedBy.Width = 101;
            // 
            // colEdate
            // 
            this.colEdate.AppearanceCell.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colEdate.AppearanceCell.Options.UseFont = true;
            this.colEdate.AppearanceCell.Options.UseTextOptions = true;
            this.colEdate.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colEdate.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colEdate.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colEdate.AppearanceHeader.Options.UseFont = true;
            this.colEdate.AppearanceHeader.Options.UseTextOptions = true;
            this.colEdate.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colEdate.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.colEdate.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colEdate.Caption = "Extra Date";
            this.colEdate.FieldName = "extra_approved_date";
            this.colEdate.Name = "colEdate";
            this.colEdate.OptionsColumn.AllowEdit = false;
            this.colEdate.OptionsColumn.ReadOnly = true;
            this.colEdate.Visible = true;
            this.colEdate.VisibleIndex = 12;
            this.colEdate.Width = 55;
            // 
            // colEtype
            // 
            this.colEtype.AppearanceCell.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colEtype.AppearanceCell.Options.UseFont = true;
            this.colEtype.AppearanceCell.Options.UseTextOptions = true;
            this.colEtype.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colEtype.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colEtype.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colEtype.AppearanceHeader.Options.UseFont = true;
            this.colEtype.AppearanceHeader.Options.UseTextOptions = true;
            this.colEtype.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colEtype.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.colEtype.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colEtype.Caption = "Extra Type";
            this.colEtype.FieldName = "had_extra_type";
            this.colEtype.Name = "colEtype";
            this.colEtype.OptionsColumn.AllowEdit = false;
            this.colEtype.OptionsColumn.ReadOnly = true;
            this.colEtype.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Custom, "Etype", "Total Days -")});
            this.colEtype.Visible = true;
            this.colEtype.VisibleIndex = 13;
            this.colEtype.Width = 95;
            // 
            // colFull
            // 
            this.colFull.AppearanceCell.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colFull.AppearanceCell.Options.UseFont = true;
            this.colFull.AppearanceCell.Options.UseTextOptions = true;
            this.colFull.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colFull.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colFull.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colFull.AppearanceHeader.Options.UseFont = true;
            this.colFull.AppearanceHeader.Options.UseTextOptions = true;
            this.colFull.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colFull.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.colFull.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colFull.Caption = "Full";
            this.colFull.FieldName = "had_attendance_days";
            this.colFull.Name = "colFull";
            this.colFull.OptionsColumn.AllowEdit = false;
            this.colFull.OptionsColumn.ReadOnly = true;
            this.colFull.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "Full", "{0:0.##}")});
            this.colFull.Visible = true;
            this.colFull.VisibleIndex = 14;
            this.colFull.Width = 60;
            // 
            // colLate
            // 
            this.colLate.AppearanceCell.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colLate.AppearanceCell.Options.UseFont = true;
            this.colLate.AppearanceCell.Options.UseTextOptions = true;
            this.colLate.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colLate.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colLate.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colLate.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.colLate.AppearanceHeader.Options.UseFont = true;
            this.colLate.AppearanceHeader.Options.UseForeColor = true;
            this.colLate.AppearanceHeader.Options.UseTextOptions = true;
            this.colLate.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colLate.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.colLate.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colLate.Caption = "Late";
            this.colLate.FieldName = "had_late_day";
            this.colLate.Name = "colLate";
            this.colLate.OptionsColumn.ReadOnly = true;
            this.colLate.OptionsColumn.ShowCaption = false;
            this.colLate.Width = 63;
            // 
            // Cont
            // 
            this.Cont.AppearanceCell.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cont.AppearanceCell.Options.UseFont = true;
            this.Cont.AppearanceCell.Options.UseTextOptions = true;
            this.Cont.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.Cont.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cont.AppearanceHeader.Options.UseFont = true;
            this.Cont.AppearanceHeader.Options.UseTextOptions = true;
            this.Cont.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.Cont.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.Cont.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.Cont.Caption = "Clock Cont.";
            this.Cont.ColumnEdit = this.repositoryItemCheckEdit1;
            this.Cont.FieldName = "had_continued_status";
            this.Cont.Name = "Cont";
            this.Cont.Visible = true;
            this.Cont.VisibleIndex = 4;
            this.Cont.Width = 48;
            // 
            // repositoryItemCheckEdit1
            // 
            this.repositoryItemCheckEdit1.AutoHeight = false;
            this.repositoryItemCheckEdit1.Name = "repositoryItemCheckEdit1";
            this.repositoryItemCheckEdit1.NullStyle = DevExpress.XtraEditors.Controls.StyleIndeterminate.Unchecked;
            // 
            // ExtraCont
            // 
            this.ExtraCont.AppearanceCell.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExtraCont.AppearanceCell.Options.UseFont = true;
            this.ExtraCont.AppearanceCell.Options.UseTextOptions = true;
            this.ExtraCont.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.ExtraCont.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExtraCont.AppearanceHeader.Options.UseFont = true;
            this.ExtraCont.AppearanceHeader.Options.UseTextOptions = true;
            this.ExtraCont.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.ExtraCont.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.ExtraCont.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.ExtraCont.Caption = "Extra Cont.";
            this.ExtraCont.ColumnEdit = this.repositoryItemCheckEdit2;
            this.ExtraCont.FieldName = "extra_cont";
            this.ExtraCont.Name = "ExtraCont";
            this.ExtraCont.Visible = true;
            this.ExtraCont.VisibleIndex = 8;
            this.ExtraCont.Width = 38;
            // 
            // repositoryItemCheckEdit2
            // 
            this.repositoryItemCheckEdit2.AutoHeight = false;
            this.repositoryItemCheckEdit2.Name = "repositoryItemCheckEdit2";
            this.repositoryItemCheckEdit2.NullStyle = DevExpress.XtraEditors.Controls.StyleIndeterminate.Unchecked;
            // 
            // gridView1
            // 
            this.gridView1.GridControl = this.gcInquiry;
            this.gridView1.Name = "gridView1";
            // 
            // labelControl6
            // 
            this.labelControl6.Appearance.BackColor = System.Drawing.Color.White;
            this.labelControl6.Appearance.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl6.Appearance.Options.UseBackColor = true;
            this.labelControl6.Appearance.Options.UseFont = true;
            this.labelControl6.Location = new System.Drawing.Point(164, 91);
            this.labelControl6.Name = "labelControl6";
            this.labelControl6.Size = new System.Drawing.Size(64, 17);
            this.labelControl6.TabIndex = 10;
            this.labelControl6.Text = "Clock Data";
            this.labelControl6.Visible = false;
            // 
            // labelControl7
            // 
            this.labelControl7.Appearance.BackColor = System.Drawing.Color.White;
            this.labelControl7.Appearance.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl7.Appearance.Options.UseBackColor = true;
            this.labelControl7.Appearance.Options.UseFont = true;
            this.labelControl7.Location = new System.Drawing.Point(686, 91);
            this.labelControl7.Name = "labelControl7";
            this.labelControl7.Size = new System.Drawing.Size(72, 17);
            this.labelControl7.TabIndex = 16;
            this.labelControl7.Text = "Extra Hours";
            this.labelControl7.Visible = false;
            // 
            // pnlService
            // 
            this.pnlService.Controls.Add(this.labelControl11);
            this.pnlService.Controls.Add(this.labelControl10);
            this.pnlService.Controls.Add(this.gcmeter);
            this.pnlService.Location = new System.Drawing.Point(105, 62);
            this.pnlService.Name = "pnlService";
            this.pnlService.Size = new System.Drawing.Size(443, 475);
            this.pnlService.TabIndex = 26;
            this.pnlService.Visible = false;
            // 
            // labelControl11
            // 
            this.labelControl11.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("labelControl11.ImageOptions.Image")));
            this.labelControl11.Location = new System.Drawing.Point(414, 5);
            this.labelControl11.Name = "labelControl11";
            this.labelControl11.Size = new System.Drawing.Size(24, 24);
            this.labelControl11.TabIndex = 27;
            this.labelControl11.Click += new System.EventHandler(this.labelControl11_Click);
            // 
            // labelControl10
            // 
            this.labelControl10.Appearance.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl10.Appearance.ForeColor = System.Drawing.Color.Black;
            this.labelControl10.Appearance.Options.UseFont = true;
            this.labelControl10.Appearance.Options.UseForeColor = true;
            this.labelControl10.Location = new System.Drawing.Point(5, 12);
            this.labelControl10.Name = "labelControl10";
            this.labelControl10.Size = new System.Drawing.Size(107, 17);
            this.labelControl10.TabIndex = 19;
            this.labelControl10.Text = "Select Service No ";
            // 
            // gcmeter
            // 
            this.gcmeter.AllowDrop = true;
            this.gcmeter.DataSource = this.tblservicenoBindingSource;
            this.gcmeter.Location = new System.Drawing.Point(5, 41);
            this.gcmeter.MainView = this.gvmeter;
            this.gcmeter.MenuManager = this.xrDesignBarManager1;
            this.gcmeter.Name = "gcmeter";
            this.gcmeter.Size = new System.Drawing.Size(433, 429);
            this.gcmeter.TabIndex = 26;
            this.gcmeter.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gvmeter});
            // 
            // tblservicenoBindingSource
            // 
            this.tblservicenoBindingSource.DataMember = "tbl_service_no";
            this.tblservicenoBindingSource.DataSource = this.dAL_DS_Inguiry;
            // 
            // gvmeter
            // 
            this.gvmeter.ColumnPanelRowHeight = 49;
            this.gvmeter.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colv_service_no,
            this.colv_name,
            this.colv_barcode_no});
            this.gvmeter.GridControl = this.gcmeter;
            this.gvmeter.GroupRowHeight = 30;
            this.gvmeter.Name = "gvmeter";
            this.gvmeter.OptionsBehavior.Editable = false;
            this.gvmeter.OptionsBehavior.ReadOnly = true;
            this.gvmeter.OptionsDetail.EnableMasterViewMode = false;
            this.gvmeter.OptionsFind.AlwaysVisible = true;
            this.gvmeter.OptionsPrint.EnableAppearanceEvenRow = true;
            this.gvmeter.OptionsView.ShowGroupPanel = false;
            this.gvmeter.OptionsView.ShowHorizontalLines = DevExpress.Utils.DefaultBoolean.True;
            this.gvmeter.OptionsView.ShowIndicator = false;
            this.gvmeter.RowHeight = 26;
            this.gvmeter.DoubleClick += new System.EventHandler(this.gvmeter_DoubleClick);
            // 
            // colv_service_no
            // 
            this.colv_service_no.AppearanceCell.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colv_service_no.AppearanceCell.Options.UseFont = true;
            this.colv_service_no.AppearanceCell.Options.UseTextOptions = true;
            this.colv_service_no.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colv_service_no.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colv_service_no.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colv_service_no.AppearanceHeader.Options.UseFont = true;
            this.colv_service_no.AppearanceHeader.Options.UseTextOptions = true;
            this.colv_service_no.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colv_service_no.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.colv_service_no.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colv_service_no.Caption = "Service No";
            this.colv_service_no.FieldName = "v_service_no";
            this.colv_service_no.Name = "colv_service_no";
            this.colv_service_no.Visible = true;
            this.colv_service_no.VisibleIndex = 0;
            this.colv_service_no.Width = 82;
            // 
            // colv_name
            // 
            this.colv_name.AppearanceCell.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colv_name.AppearanceCell.Options.UseFont = true;
            this.colv_name.AppearanceCell.Options.UseTextOptions = true;
            this.colv_name.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colv_name.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colv_name.AppearanceHeader.Options.UseFont = true;
            this.colv_name.AppearanceHeader.Options.UseTextOptions = true;
            this.colv_name.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colv_name.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.colv_name.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colv_name.Caption = "Name";
            this.colv_name.FieldName = "v_name";
            this.colv_name.Name = "colv_name";
            this.colv_name.Visible = true;
            this.colv_name.VisibleIndex = 1;
            this.colv_name.Width = 268;
            // 
            // colv_barcode_no
            // 
            this.colv_barcode_no.AppearanceCell.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colv_barcode_no.AppearanceCell.Options.UseFont = true;
            this.colv_barcode_no.AppearanceCell.Options.UseTextOptions = true;
            this.colv_barcode_no.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colv_barcode_no.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colv_barcode_no.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colv_barcode_no.AppearanceHeader.Options.UseFont = true;
            this.colv_barcode_no.AppearanceHeader.Options.UseTextOptions = true;
            this.colv_barcode_no.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colv_barcode_no.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.colv_barcode_no.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colv_barcode_no.Caption = "Barcode No";
            this.colv_barcode_no.FieldName = "v_barcode_no";
            this.colv_barcode_no.Name = "colv_barcode_no";
            this.colv_barcode_no.Visible = true;
            this.colv_barcode_no.VisibleIndex = 2;
            this.colv_barcode_no.Width = 81;
            // 
            // labelControl8
            // 
            this.labelControl8.Appearance.BackColor = System.Drawing.Color.White;
            this.labelControl8.Appearance.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl8.Appearance.ForeColor = System.Drawing.Color.DodgerBlue;
            this.labelControl8.Appearance.Options.UseBackColor = true;
            this.labelControl8.Appearance.Options.UseFont = true;
            this.labelControl8.Appearance.Options.UseForeColor = true;
            this.labelControl8.Location = new System.Drawing.Point(1, 115);
            this.labelControl8.Name = "labelControl8";
            this.labelControl8.Size = new System.Drawing.Size(109, 17);
            this.labelControl8.TabIndex = 31;
            this.labelControl8.Text = "Summary Details :";
            // 
            // gcView
            // 
            this.gcView.DataSource = this.tblviewBindingSource;
            this.gcView.Location = new System.Drawing.Point(5, 37);
            this.gcView.MainView = this.gvView;
            this.gcView.MenuManager = this.xrDesignBarManager1;
            this.gcView.Name = "gcView";
            this.gcView.Size = new System.Drawing.Size(618, 460);
            this.gcView.TabIndex = 36;
            this.gcView.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gvView});
            this.gcView.Click += new System.EventHandler(this.gcView_Click);
            // 
            // tblviewBindingSource
            // 
            this.tblviewBindingSource.DataMember = "tbl_view";
            this.tblviewBindingSource.DataSource = this.dAL_DS_Inguiry;
            // 
            // gvView
            // 
            this.gvView.ColumnPanelRowHeight = 49;
            this.gvView.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colhev_extra_code,
            this.colhev_extra_narration,
            this.ExtraDays});
            this.gvView.GridControl = this.gcView;
            this.gvView.Name = "gvView";
            this.gvView.OptionsBehavior.Editable = false;
            this.gvView.OptionsBehavior.ReadOnly = true;
            this.gvView.OptionsDetail.EnableMasterViewMode = false;
            this.gvView.OptionsFind.AlwaysVisible = true;
            this.gvView.OptionsView.ShowGroupPanel = false;
            this.gvView.OptionsView.ShowHorizontalLines = DevExpress.Utils.DefaultBoolean.True;
            this.gvView.OptionsView.ShowIndicator = false;
            // 
            // colhev_extra_code
            // 
            this.colhev_extra_code.AppearanceCell.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colhev_extra_code.AppearanceCell.Options.UseFont = true;
            this.colhev_extra_code.AppearanceCell.Options.UseTextOptions = true;
            this.colhev_extra_code.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colhev_extra_code.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colhev_extra_code.AppearanceHeader.Options.UseFont = true;
            this.colhev_extra_code.AppearanceHeader.Options.UseTextOptions = true;
            this.colhev_extra_code.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colhev_extra_code.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.colhev_extra_code.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colhev_extra_code.Caption = "Extra Code";
            this.colhev_extra_code.FieldName = "hev_extra_code";
            this.colhev_extra_code.Name = "colhev_extra_code";
            this.colhev_extra_code.Visible = true;
            this.colhev_extra_code.VisibleIndex = 0;
            this.colhev_extra_code.Width = 187;
            // 
            // colhev_extra_narration
            // 
            this.colhev_extra_narration.AppearanceCell.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colhev_extra_narration.AppearanceCell.Options.UseFont = true;
            this.colhev_extra_narration.AppearanceCell.Options.UseTextOptions = true;
            this.colhev_extra_narration.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colhev_extra_narration.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colhev_extra_narration.AppearanceHeader.Options.UseFont = true;
            this.colhev_extra_narration.AppearanceHeader.Options.UseTextOptions = true;
            this.colhev_extra_narration.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colhev_extra_narration.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.colhev_extra_narration.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colhev_extra_narration.Caption = "Extra Narration";
            this.colhev_extra_narration.FieldName = "hev_extra_narration";
            this.colhev_extra_narration.Name = "colhev_extra_narration";
            this.colhev_extra_narration.Visible = true;
            this.colhev_extra_narration.VisibleIndex = 1;
            this.colhev_extra_narration.Width = 271;
            // 
            // ExtraDays
            // 
            this.ExtraDays.AppearanceCell.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExtraDays.AppearanceCell.Options.UseFont = true;
            this.ExtraDays.AppearanceCell.Options.UseTextOptions = true;
            this.ExtraDays.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.ExtraDays.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExtraDays.AppearanceHeader.Options.UseFont = true;
            this.ExtraDays.AppearanceHeader.Options.UseTextOptions = true;
            this.ExtraDays.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.ExtraDays.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.ExtraDays.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.ExtraDays.Caption = "Extra Days";
            this.ExtraDays.FieldName = "hev_extra_days";
            this.ExtraDays.Name = "ExtraDays";
            this.ExtraDays.Visible = true;
            this.ExtraDays.VisibleIndex = 2;
            this.ExtraDays.Width = 158;
            // 
            // pnlView
            // 
            this.pnlView.Controls.Add(this.lblsup);
            this.pnlView.Controls.Add(this.labelControl9);
            this.pnlView.Controls.Add(this.gcView);
            this.pnlView.Location = new System.Drawing.Point(285, 129);
            this.pnlView.Name = "pnlView";
            this.pnlView.Size = new System.Drawing.Size(629, 502);
            this.pnlView.TabIndex = 37;
            this.pnlView.Visible = false;
            this.pnlView.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlView_Paint);
            // 
            // lblsup
            // 
            this.lblsup.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("lblsup.ImageOptions.Image")));
            this.lblsup.Location = new System.Drawing.Point(599, 4);
            this.lblsup.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.lblsup.Name = "lblsup";
            this.lblsup.Size = new System.Drawing.Size(24, 24);
            this.lblsup.TabIndex = 39;
            this.lblsup.Click += new System.EventHandler(this.lblsup_Click);
            // 
            // labelControl9
            // 
            this.labelControl9.Appearance.BackColor = System.Drawing.Color.White;
            this.labelControl9.Appearance.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl9.Appearance.ForeColor = System.Drawing.Color.DodgerBlue;
            this.labelControl9.Appearance.Options.UseBackColor = true;
            this.labelControl9.Appearance.Options.UseFont = true;
            this.labelControl9.Appearance.Options.UseForeColor = true;
            this.labelControl9.Location = new System.Drawing.Point(5, 14);
            this.labelControl9.Name = "labelControl9";
            this.labelControl9.Size = new System.Drawing.Size(65, 17);
            this.labelControl9.TabIndex = 38;
            this.labelControl9.Text = "Summary :";
            // 
            // Form1
            // 
            this.AllowMdiBar = true;
            this.Appearance.BackColor = System.Drawing.Color.White;
            this.Appearance.Options.UseBackColor = true;
            this.Appearance.Options.UseFont = true;
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(1151, 976);
            this.Controls.Add(this.labelControl8);
            this.Controls.Add(this.labelControl7);
            this.Controls.Add(this.labelControl6);
            this.Controls.Add(this.gcInquiry);
            this.Controls.Add(this.panelControl1);
            this.Controls.Add(this.pnlService);
            this.Controls.Add(this.pnlView);
            this.Controls.Add(this.barDockControlLeft);
            this.Controls.Add(this.barDockControlRight);
            this.Controls.Add(this.barDockControlBottom);
            this.Controls.Add(this.barDockControlTop);
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IconOptions.ShowIcon = false;
            this.LookAndFeel.SkinName = "Metropolis";
            this.LookAndFeel.UseDefaultLookAndFeel = false;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Executives Extra Hours Inquiry";
            this.Load += new System.EventHandler(this.UC_Inquiry_Load);
            ((System.ComponentModel.ISupportInitialize)(this.xrDesignBarManager1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrDesignDockManager1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.recentlyUsedItemsComboBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.designRepositoryItemComboBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.designRepositoryItemComboBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).EndInit();
            this.panelControl1.ResumeLayout(false);
            this.panelControl1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cmbMonth.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmbYear.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBarcode.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtName.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtServiceNo.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picturePath.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.reportDesigner1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcInquiry)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblDataBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dAL_DS_Inguiry)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvInquiry)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pnlService)).EndInit();
            this.pnlService.ResumeLayout(false);
            this.pnlService.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gcmeter)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblservicenoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvmeter)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.behaviorManager1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblviewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pnlView)).EndInit();
            this.pnlView.ResumeLayout(false);
            this.pnlView.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraEditors.PanelControl panelControl1;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.TextEdit txtServiceNo;
        private DevExpress.XtraEditors.LabelControl labelControl5;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraReports.UserDesigner.XRDesignBarManager xrDesignBarManager1;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem2;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiOpenFile;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem3;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem11;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem4;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiUndo;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiRedo;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiCut;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiCopy;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiPaste;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem5;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem6;
        private DevExpress.XtraBars.BarSubItem msiTabButtons;
        private DevExpress.XtraReports.UserDesigner.BarReportTabButtonsListItem barReportTabButtonsListItem1;
        private DevExpress.XtraBars.BarSubItem barSubItem1;
        private DevExpress.XtraReports.UserDesigner.XRBarToolbarsListItem xrBarToolbarsListItem1;
        private DevExpress.XtraBars.BarSubItem barSubItem2;
        private DevExpress.XtraReports.UserDesigner.BarDockPanelsListItem barDockPanelsListItem1;
        private DevExpress.XtraBars.BarSubItem msiFormat;
        private DevExpress.XtraReports.UserDesigner.CommandColorBarItem bbiForeColor;
        private DevExpress.XtraReports.UserDesigner.CommandColorBarItem bbiBackColor;
        private DevExpress.XtraBars.BarSubItem msiFont;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiFontBold;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiFontItalic;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiFontUnderline;
        private DevExpress.XtraBars.BarSubItem msiJustify;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiJustifyLeft;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiJustifyCenter;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiJustifyRight;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiJustifyJustify;
        private DevExpress.XtraBars.BarSubItem msiAlign;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiAlignLeft;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiAlignVerticalCenters;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiAlignRight;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiAlignTop;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiAlignHorizontalCenters;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiAlignBottom;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiAlignToGrid;
        private DevExpress.XtraBars.BarSubItem msiSameSize;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiSizeToControlWidth;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiSizeToGrid;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiSizeToControlHeight;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiSizeToControl;
        private DevExpress.XtraBars.BarSubItem msiHorizontalSpacing;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiHorizSpaceMakeEqual;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiHorizSpaceIncrease;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiHorizSpaceDecrease;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiHorizSpaceConcatenate;
        private DevExpress.XtraBars.BarSubItem msiVerticalSpacing;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiVertSpaceMakeEqual;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiVertSpaceIncrease;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiVertSpaceDecrease;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiVertSpaceConcatenate;
        private DevExpress.XtraBars.BarSubItem bsiCenter;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiCenterHorizontally;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiCenterVertically;
        private DevExpress.XtraBars.BarSubItem msiOrder;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiBringToFront;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiSendToBack;
        private DevExpress.XtraBars.BarSubItem msiWindow;
        private DevExpress.XtraReports.UserDesigner.CommandBarCheckItem msiWindowInterface;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem8;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem9;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem10;
        private DevExpress.XtraBars.BarMdiChildrenListItem msiWindows;
        private DevExpress.XtraBars.BarEditItem beiFontName;
        private DevExpress.XtraReports.UserDesigner.RecentlyUsedItemsComboBox recentlyUsedItemsComboBox1;
        private DevExpress.XtraBars.BarEditItem beiFontSize;
        private DevExpress.XtraReports.UserDesigner.DesignRepositoryItemComboBox designRepositoryItemComboBox1;
        private DevExpress.XtraBars.BarStaticItem bsiHint;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiZoomOut;
        private DevExpress.XtraReports.UserDesigner.XRZoomBarEditItem bbiZoom;
        private DevExpress.XtraReports.UserDesigner.DesignRepositoryItemComboBox designRepositoryItemComboBox2;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiZoomIn;
        private DevExpress.XtraBars.BarDockControl barDockControlTop;
        private DevExpress.XtraBars.BarDockControl barDockControlBottom;
        private DevExpress.XtraBars.BarDockControl barDockControlLeft;
        private DevExpress.XtraBars.BarDockControl barDockControlRight;
        private DevExpress.XtraReports.UserDesigner.XRDesignDockManager xrDesignDockManager1;
        private DevExpress.XtraEditors.TextEdit txtBarcode;
        private DevExpress.XtraEditors.TextEdit txtName;
        private DevExpress.XtraReports.UserDesigner.Native.StandardReportDesigner standardReportDesigner1;
        private DevExpress.XtraReports.UserDesigner.XRDesignMdiController reportDesigner1;
        private DevExpress.XtraEditors.LabelControl labelControl7;
        private DevExpress.XtraEditors.LabelControl labelControl6;
        private DevExpress.XtraGrid.GridControl gcInquiry;
        private DevExpress.XtraGrid.Views.Grid.GridView gvInquiry;
        private DevExpress.XtraEditors.PictureEdit picturePath;
        private DevExpress.XtraEditors.ComboBoxEdit cmbMonth;
        private DevExpress.XtraEditors.ComboBoxEdit cmbYear;
        private System.Windows.Forms.BindingSource tblDataBindingSource;
        private DAL.DataSource.DAL_DS_Inguiry dAL_DS_Inguiry;
        private DevExpress.XtraGrid.Columns.GridColumn colLoc;
        private DevExpress.XtraGrid.Columns.GridColumn colCdate;
        private DevExpress.XtraGrid.Columns.GridColumn colDay;
        private DevExpress.XtraGrid.Columns.GridColumn colClockIn;
        private DevExpress.XtraGrid.Columns.GridColumn colClockOut;
        private DevExpress.XtraGrid.Columns.GridColumn colDutyType;
        private DevExpress.XtraGrid.Columns.GridColumn colExtraIn;
        private DevExpress.XtraGrid.Columns.GridColumn colExtraOut;
        private DevExpress.XtraGrid.Columns.GridColumn colHours;
        private DevExpress.XtraGrid.Columns.GridColumn ExtraApprovedBy;
        private DevExpress.XtraGrid.Columns.GridColumn colEdate;
        private DevExpress.XtraGrid.Columns.GridColumn colEtype;
        private DevExpress.XtraGrid.Columns.GridColumn colFull;
        private DevExpress.XtraGrid.Columns.GridColumn colLate;
        private DevExpress.XtraEditors.SimpleButton btnSummary;
        private DevExpress.XtraEditors.PanelControl pnlService;
        private DevExpress.XtraEditors.LabelControl labelControl11;
        private DevExpress.XtraEditors.LabelControl labelControl10;
        private DevExpress.XtraGrid.GridControl gcmeter;
        private DevExpress.XtraGrid.Views.Grid.GridView gvmeter;
        private System.Windows.Forms.BindingSource tblservicenoBindingSource;
        private DevExpress.XtraGrid.Columns.GridColumn colv_service_no;
        private DevExpress.XtraGrid.Columns.GridColumn colv_name;
        private DevExpress.XtraGrid.Columns.GridColumn colv_barcode_no;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox1;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DevExpress.Utils.Behaviors.BehaviorManager behaviorManager1;
        private DevExpress.XtraEditors.LabelControl labelControl8;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit1;
        private DevExpress.XtraGrid.Columns.GridColumn ExtraCont;
        private DevExpress.XtraGrid.Columns.GridColumn Cont;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit2;
        private DevExpress.XtraEditors.SimpleButton btnClear;
        private DevExpress.XtraEditors.SimpleButton btnView;
        private DevExpress.XtraEditors.PanelControl pnlView;
        private DevExpress.XtraEditors.LabelControl lblsup;
        private DevExpress.XtraEditors.LabelControl labelControl9;
        private DevExpress.XtraGrid.GridControl gcView;
        private System.Windows.Forms.BindingSource tblviewBindingSource;
        private DevExpress.XtraGrid.Views.Grid.GridView gvView;
        private DevExpress.XtraGrid.Columns.GridColumn colhev_extra_code;
        private DevExpress.XtraGrid.Columns.GridColumn colhev_extra_narration;
        private DevExpress.XtraGrid.Columns.GridColumn ExtraDays;
    }
}