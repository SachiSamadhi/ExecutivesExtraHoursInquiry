﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExecutivesExtraHoursInquiry.BLL
{
    class BLL_CS_Inquiry
    {
        DAL.DAL_CS_Inquiry dal = new DAL.DAL_CS_Inquiry();

        //Read Service No
        public DataTable ServiceNo()
        {
            return dal.readService();
        }

        //Load photo
        public DataTable PhotoPath()
        {
            return dal.readPhotoPath();
        }

        private string GetMonthNumber(string monthName)
        {
            switch (monthName)
            {
                case "January": return "01";
                case "February": return "02";
                case "March": return "03";
                case "April": return "04";
                case "May": return "05";
                case "June": return "06";
                case "July": return "07";
                case "August": return "08";
                case "September": return "09";
                case "October": return "10";
                case "November": return "11";
                case "December": return "12";
                default: return "";
            }
        }

        //Load Button

        public DataTable SummaryTable(string barcodeNo, string year, string monthName)
        {
            string month = GetMonthNumber(monthName);
            return dal.Summary(barcodeNo, year, month);
        }

        //View
        public DataTable SummaryView(string barcodeNo, string year, string monthName)
        {
            string month = GetMonthNumber(monthName);
            return dal.ViewSum(barcodeNo, year, month);
        }

    }
}
