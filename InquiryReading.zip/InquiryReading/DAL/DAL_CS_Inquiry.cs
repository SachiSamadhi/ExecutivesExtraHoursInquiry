﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.OracleClient;

namespace ExecutivesExtraHoursInquiry.DAL
{
    class DAL_CS_Inquiry
    {
        //Read Service No - When mouse double click (V1)
        public DataTable readService()
        {
            DBconnect.connect();

            DAL.DataSource.DAL_DS_Inguiry ds = new DataSource.DAL_DS_Inguiry();
            DataTable dt = ds.tbl_service_no;

            string query = @"SELECT v_service_no,
                                    v_name,
                                    v_barcode_no
                             FROM hrm_employees_view
                             ORDER BY v_service_no";

            OracleDataReader odr = DBconnect.readtable(query, null);

            while (odr.Read())
            {
                DataRow r = dt.NewRow();
                r["v_service_no"] = odr["v_service_no"].ToString();
                r["v_name"] = odr["v_name"].ToString();
                r["v_barcode_no"] = odr["v_barcode_no"].ToString();

                dt.Rows.Add(r);


            }

            odr.Close();
            return dt;
            
        }

        //Read Photo Path
        public DataTable readPhotoPath()
        {
            DBconnect.connect();

            DAL.DataSource.DAL_DS_Inguiry ds = new DataSource.DAL_DS_Inguiry();
            DataTable dt = ds.tbl_photo_path;   

            string query = @"SELECT cpd_photo_path
                     FROM cdl_path_details
                     WHERE cpd_status = 'A'";

            OracleDataReader odr = DBconnect.readtable(query, null);

            while (odr.Read())
            {
                DataRow r = dt.NewRow();
                r["cpd_photo_path"] = odr["cpd_photo_path"].ToString();

                dt.Rows.Add(r);
            }

            odr.Close();
            return dt;
        }

        //Load Button

        public DataTable Summary(string barcodeNo, string year, string monthName)
        {
            DBconnect.connect();

            DAL.DataSource.DAL_DS_Inguiry ds = new DataSource.DAL_DS_Inguiry();
            DataTable dt = ds.tbl_Data;

            string query = @"
                        SELECT 
    had.had_loc_code,
    had.had_date,
    UPPER(SUBSTR(TO_CHAR(had.had_clock_in,'DAY'),1,3)) AS had_day,
    TO_CHAR(had.had_clock_in, 'RRRR-MM-DD') AS had_clock_in,
    had.had_continued_status,
    TO_CHAR(had.had_clock_out,'RRRR-MM-DD') AS had_clock_out,
    had.had_endex_hours,
    otpack.get_eot_in(had.had_barcode_no, TRUNC(had.had_clock_in)) AS extra_in,
    otpack.get_eot_out(had.had_barcode_no, TRUNC(had.had_clock_in)) AS extra_out,
    otpack.get_continued_status(had.had_barcode_no, TRUNC(had.had_clock_in)) AS extra_cont,
    otpack.get_approved_date(had.had_barcode_no, TRUNC(had.had_clock_in)) AS extra_approved_date,
    otpack.get_approved_by(had.had_barcode_no, TRUNC(had.had_clock_in)) AS extra_approved_name,
    otpack.get_extra_type(had.had_barcode_no, TRUNC(had.had_clock_in)) AS duty_type,
    had.had_attendance_days,
    had.had_late_day,
    otpack.get_extra_type(had.had_barcode_no, TRUNC(had.had_clock_in)) AS had_extra_type
FROM hrm_attendance_details had
WHERE had.had_barcode_no = '" + barcodeNo + @"'
  AND TO_CHAR(had.had_clock_in,'YYYY') = '" + year + @"'
  AND TO_CHAR(had.had_clock_in,'MM') = '" + monthName.PadLeft(2, '0') + @"'
ORDER BY had.had_clock_in
        ";

            OracleDataReader odr = DBconnect.readtable(query, null);

            while (odr.Read())
            {
                DataRow r = dt.NewRow();

                r["had_loc_code"] = odr["had_loc_code"].ToString();
                r["had_date"] = odr["had_date"].ToString();
                r["had_day"] = odr["had_day"].ToString();
                r["had_clock_in"] = odr["had_clock_in"].ToString();
                r["had_continued_status"] = odr["had_continued_status"].ToString();
                r["had_clock_out"] = odr["had_clock_out"].ToString();
                r["had_endex_hours"] = odr["had_endex_hours"].ToString();
                r["extra_in"] = odr["extra_in"].ToString();
                r["extra_out"] = odr["extra_out"].ToString();
                r["extra_cont"] = odr["extra_cont"].ToString();
                
                r["extra_approved_date"] = odr["extra_approved_date"].ToString();
                r["extra_approved_name"] = odr["extra_approved_name"].ToString();          
                r["duty_type"] = odr["duty_type"].ToString();
                r["had_late_day"] = odr["had_late_day"].ToString();
                r["had_attendance_days"] = odr["had_attendance_days"].ToString();      
                r["had_extra_type"] = odr["had_extra_type"].ToString();  

                dt.Rows.Add(r);
            }

            odr.Close();
            return dt;

        }

        //View Summary
        public DataTable ViewSum(string barcodeNo, string year, string monthName)
        {
            DBconnect.connect();

            DAL.DataSource.DAL_DS_Inguiry ds = new DataSource.DAL_DS_Inguiry();
            DataTable dt = ds.tbl_view;

            string query = @"SELECT 
    hev_extra_code,
    hev_extra_narration
    
FROM hrm_extrahours_view
WHERE hev_year = '" + year + @"'
  AND hev_month = '" + monthName.PadLeft(2, '0') + @"'
  AND hev_barcode_no = '" + barcodeNo + @"'
ORDER BY hev_extra_code";


            OracleDataReader odr = DBconnect.readtable(query, null);

            while (odr.Read())
            {

                DataRow r = dt.NewRow();

                r["hev_extra_code"] = odr["hev_extra_code"].ToString();
                r["hev_extra_narration"] = odr["hev_extra_narration"].ToString();
               

                dt.Rows.Add(r);
            }

            odr.Close();
            return dt;
        }
    }
}
