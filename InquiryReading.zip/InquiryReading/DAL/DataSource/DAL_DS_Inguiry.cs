﻿namespace ExecutivesExtraHoursInquiry.DAL.DataSource
{


    partial class DAL_DS_Inguiry
    {
        partial class tbl_DataDataTable
        {
        }

        partial class tbl_service_noDataTable
        {
        }
    }
}
